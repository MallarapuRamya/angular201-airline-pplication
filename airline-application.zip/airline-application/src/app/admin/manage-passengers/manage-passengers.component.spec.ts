import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagePassengersComponent } from './manage-passengers.component';
import { RouterTestingModule } from '@angular/router/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { StoreModule } from '@ngrx/store';

describe('ManagePassengersComponent', () => {
  let component: ManagePassengersComponent;
  let fixture: ComponentFixture<ManagePassengersComponent>;
   
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagePassengersComponent ],
      imports : [RouterTestingModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagePassengersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
