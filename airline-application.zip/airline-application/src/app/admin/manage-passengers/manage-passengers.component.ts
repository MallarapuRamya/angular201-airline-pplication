import { Component, OnInit, ViewChild } from '@angular/core';
import { Passengers } from 'src/app/models/passengers.model';
import { Observable } from 'rxjs';
import {  Store } from '@ngrx/store';
import { PassengerState } from 'src/app/store/reducers/passenger.reducer';
import { Router, ActivatedRoute } from '@angular/router';
import { State } from '../../store/reducers/flight.reducer';
import {MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import * as fromApp from '../../store/reducers/app.reducer';
import * as PassengerActions from '../../store/actions/passenger.actions'


@Component({
  selector: 'app-manage-passengers',
  templateUrl: './manage-passengers.component.html',
  styleUrls: ['./manage-passengers.component.css']
})
export class ManagePassengersComponent implements OnInit {

  passengers : Passengers[]=[];
  filteredPassengers : Passengers[]=[];
  selectedFlight : string ;
  flights$ : Observable<State>;
  passengers$ : Observable<PassengerState>;
  passenger : Passengers;
  filterValues : string[]=["Please select","Passport","DOB","Address","Clear selection"];
  selectedValue: string = "Please select"; 
  displayedColumns: string[] = ['PassengerId','PassengerName','SeatNumber','AncillaryServices','SpecialMeals','Passport','Address','DOB','Actions'];
   dataSource : any;
   @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  constructor(
    private route : Router,private router : ActivatedRoute,
    private store : Store<fromApp.AppState>) { 

      this.passengers$ = this.store.select('passengerState');
      
    }

  ngOnInit(): void {
    
    this.getPassengers();

  this.passengers$.subscribe(
    (state : PassengerState) => {
      this.passengers = state.passengers;
      this.dataSource = new MatTableDataSource(this.passengers);
      this.dataSource.paginator = this.paginator;  
     });   
  }

  getPassengers()
  {
    this.store.dispatch(new PassengerActions.LoadPassengers());
  }
  onAdd(){
    this.route.navigate(['../add'], {relativeTo : this.router});
  }
  onUpdate(row : Passengers){

    this.store.dispatch(new PassengerActions.CurrentPassengerIdSelected(row.id));
    this.route.navigate(['../update'], {relativeTo : this.router})
  }

  onChange(event : any){
    
    switch(event.value){
      case 'Passport' :
        this.filteredPassengers = this.passengers.filter(passenger => passenger.passport === "");
        this.dataSource = new MatTableDataSource(this.filteredPassengers);
        this.dataSource.paginator = this.paginator;
        break;
      case 'DOB' :
        this.filteredPassengers = this.passengers.filter(passenger => passenger.dateOfBirth === "");
        this.dataSource = new MatTableDataSource(this.filteredPassengers);
        this.dataSource.paginator = this.paginator;
        break;
      case 'Address' :
          this.filteredPassengers = this.passengers.filter(passenger => passenger.address=== "");
          this.dataSource = new MatTableDataSource(this.filteredPassengers);
          this.dataSource.paginator = this.paginator;
          break;
      case  'Clear selection' : 
        this.dataSource = new MatTableDataSource(this.passengers);
        this.dataSource.paginator = this.paginator;
        this.selectedValue = "Please select";
        break ;
      case 'default' :
        break;
    }
  }
}