import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { State } from 'src/app/store/reducers/flight.reducer';
import { Flights } from 'src/app/models/flights.model';
import { NgForm } from '@angular/forms';
import { Passengers } from 'src/app/models/passengers.model';
import { PassengerState } from 'src/app/store/reducers/passenger.reducer';
import * as fromApp from '../../../store/reducers/app.reducer';
import * as FlightActions from '../../../store/actions/flight.actions';
import * as PassengerActions from '../../../store/actions/passenger.actions';

@Component({
  selector: 'app-add-passenger',
  templateUrl: './add-passenger.component.html',
  styleUrls: ['./add-passenger.component.css']
})
export class AddPassengerComponent implements OnInit {
 min : number = 10000;
 max : number = 20000;
 flights$ : Observable<State>;
 passenger$ : Observable<PassengerState>;
 flights : Flights[];
 submitted : boolean = false;
 passenger : Passengers;
 addedPassenger : Passengers;
 ancillaryServices : string[] = ["Extra 5kg Baggage","Fast Forward","Seat Plus"];
 specialMeals : String[] = ["Vegetable Biryani","Chicken Biryani","Veg Noodles","Chicken Noodles","Veg Meal","Non-Veg Meal","Baby Meal"];

  constructor(private store : Store<fromApp.AppState>) {

    this.flights$=this.store.select('flightState');
    this.passenger$=this.store.select('passengerState');

   }

  ngOnInit(): void {
    this.getFlights();

    this.flights$.subscribe(
      (state : State) =>(this.flights=state.flights)
    )
    
  }
  getRandomNumberBetween(min : number,max : number){
     return Math.floor(Math.random()*(max-min+1)+min)
  }
  getFlights(){

    this.store.dispatch(new FlightActions.LoadFlights());
  
    }
 
    onSubmit( form : NgForm)
   {
      this.submitted=true;
      this.passenger = new Passengers();
      this.passenger.id=this.getRandomNumberBetween(this.min, this.max);
      this.passenger.flightId=form.value.flight;
      this.passenger.name = form.value.name;
      this.passenger.passport= form.value.passport;
      this.passenger.age = form.value.age;
      this.passenger.address = form.value.address;
      this.passenger.dateOfBirth = form.value.dob;
      this.passenger.gender = form.value.gender;
      this.passenger.isCheckedIn=false; 
      if(form.value.isInfant === "")
      {
        this.passenger.infants=false;
      }
      else
      {
        this.passenger.infants=form.value.isInfant;
      }
      if(form.value.isWheelchair === "")
      {
        this.passenger.wheelchair=false;
      }
      else
      {
        this.passenger.wheelchair=form.value.isWheelchair;
      }
      
      this.passenger.seatNumber=[];
      this.passenger.ancillaryServices=form.value.services;
      this.passenger.specialMeals = form.value.meals;
      this.passenger.shopInFlight=[];

      this.store.dispatch(new PassengerActions.AddPassenger(this.passenger));
      this.passenger$.subscribe(
        (state : PassengerState) =>{
          this.addedPassenger = state.passengers.filter(state => state.id === this.passenger.id)[0];
        }
      )
      form.reset();
   }
}
