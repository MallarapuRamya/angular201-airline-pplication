import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { PassengerState } from 'src/app/store/reducers/passenger.reducer';
import { Passengers } from 'src/app/models/passengers.model';
import { State } from 'src/app/store/reducers/flight.reducer';
import { Flights } from 'src/app/models/flights.model';
import * as fromApp from '../../../store/reducers/app.reducer';
import * as PassengerActions from '../../../store/actions/passenger.actions';
import * as FlightActions from '../../../store/actions/flight.actions';

@Component({
  selector: 'app-update-passenger',
  templateUrl: './update-passenger.component.html',
  styleUrls: ['./update-passenger.component.css']
})
export class UpdatePassengerComponent implements OnInit {
passengers$ : Observable<PassengerState>;
flights$ : Observable<State>;
selectedPassenger : Passengers;
selectedPassengerId : number;
passengerChanges : Passengers;
updatedPassenger : Passengers;
submitted : boolean = false;
flights: Flights[]=[];
ancillaryServices : string[] = ["Extra 5kg Baggage","Fast Forward","Seat Plus"];
specialMeals : String[] = ["Vegetable Biryani","Chicken Biryani","Veg Noodles","Chicken Noodles","Veg Meal","Non-Veg Meal","Baby Meal"];

  constructor(private store : Store<fromApp.AppState>) {

    this.passengers$=this.store.select('passengerState');
    this.flights$ = this.store.select('flightState')

   }

  ngOnInit(): void {

    this.passengers$.subscribe(
      (state : PassengerState) =>{
        this.selectedPassengerId=state.currentPassengerIdSelected;
      }
    )
    this.passengers$.subscribe(
      (state : PassengerState) =>{
        this.selectedPassenger= state.passengers.filter(state =>(state.id === this.selectedPassengerId))[0];
      })

     this.getFlights();

      this.flights$.subscribe(
        (state : State) => {
          this.flights = state.flights
        }
      )
      
  }

  getFlights(){

    this.store.dispatch(new FlightActions.LoadFlights());
  
    }

  onSubmit( form : NgForm){

      this.submitted=true;
      this.passengerChanges =new Passengers();
      this.passengerChanges.id = this.selectedPassengerId;
      this.passengerChanges.name = form.value.name;
      this.passengerChanges.passport = form.value.passport;
      this.passengerChanges.age = form.value.age;
      this.passengerChanges.address = form.value.address;
      this.passengerChanges.flightId=form.value.flight;
      this.passengerChanges.dateOfBirth = form.value.dob;
      this.passengerChanges.gender = form.value.gender;
      if(form.value.isInfant === "")
      {
        this.passengerChanges.infants=false;
      }
      else
      {
        this.passengerChanges.infants=form.value.isInfant;
      }
      if(form.value.isWheelchair === "")
      {
        this.passengerChanges.wheelchair=false; 
      }
      else
      {
        this.passengerChanges.wheelchair=form.value.isWheelchair;
      }
      this.passengerChanges.ancillaryServices=form.value.services;
      this.passengerChanges.specialMeals = form.value.meals;

      this.store.dispatch(new PassengerActions.EditPassenger(this.passengerChanges));
      
      this.passengers$.subscribe(
        (state : PassengerState) => {
          this.updatedPassenger=state.passengers.filter(state => (state.id === this.selectedPassengerId))[0];
        })
      form.reset();
  }
  
}