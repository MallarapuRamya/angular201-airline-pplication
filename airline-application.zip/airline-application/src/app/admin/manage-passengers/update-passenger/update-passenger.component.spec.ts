import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatePassengerComponent } from './update-passenger.component';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { FormsModule } from '@angular/forms';
import { StoreModule } from '@ngrx/store';
import { Passengers } from 'src/app/models/passengers.model';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';

describe('UpdatePassengerComponent', () => {
  let component: UpdatePassengerComponent;
  let fixture: ComponentFixture<UpdatePassengerComponent>;
  let updatedPassenger : Passengers;
  let store  : MockStore;
  const initialState ={
    passengers:[]=[],
    loading :false,
    loaded : true,
    currentPassengerIdSelected : 10013
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatePassengerComponent ],
      imports : [FormsModule, StoreModule.forRoot({})],
      providers : [provideMockStore({ initialState })]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatePassengerComponent);
    component = fixture.componentInstance;
    store = TestBed.inject(MockStore);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
