import { Component, OnInit } from '@angular/core';
import { State } from 'src/app/store/reducers/flight.reducer';
import { Observable } from 'rxjs';
import { Flights } from 'src/app/models/flights.model';
import { Router, ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import { FlightAncillaryServices } from 'src/app/models/flightAncillaryServices.model';
import * as fromApp from '../../../store/reducers/app.reducer';
import * as FlightActions from '../../../store/actions/flight.actions';


@Component({
  selector: 'app-manage-ancillary',
  templateUrl: './manage-ancillary.component.html',
  styleUrls: ['./manage-ancillary.component.css']
})
export class ManageAncillaryComponent implements OnInit {

  flights$ : Observable<State>;
  selectedFlight : Flights;
  selectedFlightId : string;
  flightAncillaryServices : FlightAncillaryServices[]=[];
  flightChanges: Flights;
  selectedAncillaryId: number;
  updatedFlight: Flights;
  
  constructor(private route : Router, private router : ActivatedRoute,
    private store : Store<fromApp.AppState>) { 

      this.flights$=this.store.select('flightState');
    }

  ngOnInit(): void {

      this.flights$.subscribe(
        (state : State) =>{
          this.selectedFlightId=state.currentFlightIdSelected;
        }
      )
      
      this.flights$.subscribe(
        (state : State) =>{
          this.selectedFlight = state.flights.filter(state => (state.id === this.selectedFlightId))[0];
        });
  }
  onAdd()
  {
     this.route.navigate(['../add-ancillary'], {relativeTo : this.router});
  }
  onUpdate(id : number){

    this.store.dispatch(new FlightActions.CurrentAncillaryIdSelected(id));
    this.route.navigate(['../update-ancillary'], {relativeTo : this.router});
  }
  onDelete(id : number){

    this.store.dispatch(new FlightActions.CurrentAncillaryIdSelected(id));
    this.flights$.subscribe(
      (state : State) =>{
        this.selectedAncillaryId = state.currentAncillaryIdSelected;
      });
    this.flightChanges = new Flights();
    this.flightChanges.id = this.selectedFlightId;
    this.flightAncillaryServices = this.selectedFlight.ancillaryServices.filter(ancillary =>ancillary.serviceId !== this.selectedAncillaryId);
    this.flightChanges.ancillaryServices =this.flightAncillaryServices;

    this.store.dispatch(new FlightActions.UpdateAncillaryInFlight(this.flightChanges));
    this.flights$.subscribe((state : State) =>{
      this.updatedFlight = state.flights.filter( state =>(state.id === this.selectedFlightId))[0];

    })

     this.route.navigate(['../delete-ancillary'], {relativeTo : this.router});
  }

  onLogout(){

    localStorage.removeItem("session");
    this.route.navigate(['']);
  } 
  
}
