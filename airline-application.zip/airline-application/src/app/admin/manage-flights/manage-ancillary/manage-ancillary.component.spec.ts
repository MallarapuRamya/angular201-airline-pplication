import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageAncillaryComponent } from './manage-ancillary.component';
import { RouterTestingModule } from '@angular/router/testing';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { FormsModule } from '@angular/forms';
import { StoreModule } from '@ngrx/store';

describe('ManageAncillaryComponent', () => {
  let component: ManageAncillaryComponent;
  let fixture: ComponentFixture<ManageAncillaryComponent>;
 

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageAncillaryComponent ],
      imports : [RouterTestingModule, FormsModule],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageAncillaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
