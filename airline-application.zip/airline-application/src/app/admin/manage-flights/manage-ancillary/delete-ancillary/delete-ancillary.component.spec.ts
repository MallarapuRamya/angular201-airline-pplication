import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteAncillaryComponent } from './delete-ancillary.component';
import { RouterTestingModule } from '@angular/router/testing';

describe('DeleteAncillaryComponent', () => {
  let component: DeleteAncillaryComponent;
  let fixture: ComponentFixture<DeleteAncillaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteAncillaryComponent ],
      imports : [RouterTestingModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteAncillaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
