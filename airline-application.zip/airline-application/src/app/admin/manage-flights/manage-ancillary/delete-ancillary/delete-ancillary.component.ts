import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-ancillary',
  templateUrl: './delete-ancillary.component.html',
  styleUrls: ['./delete-ancillary.component.css']
})
export class DeleteAncillaryComponent implements OnInit {

  constructor(){}

  ngOnInit(): void {
  }

}