import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAncillaryComponent } from './add-ancillary.component';
import { RouterTestingModule } from '@angular/router/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { FormsModule } from '@angular/forms';
import { StoreModule } from '@ngrx/store';

describe('AddAncillaryComponent', () => {
  let component: AddAncillaryComponent;
  let fixture: ComponentFixture<AddAncillaryComponent>;
  let store  : MockStore;
  const initialState = {
    flights:[]=[],
    loading :false,
    loaded : false,
    //currentFlightIdSelected : "AN001",
    currentAncillaryIdSelected : null,
    currentMealIdSelected : null,
    currentPurchaseIdSelected : null
  }
  let currentFlightIdSelected : "AN001"
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddAncillaryComponent ],
      imports : [RouterTestingModule, FormsModule,StoreModule.forRoot({})],
      providers : [provideMockStore({ initialState })]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddAncillaryComponent);
    component = fixture.componentInstance;
    store = TestBed.inject(MockStore);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });

});
