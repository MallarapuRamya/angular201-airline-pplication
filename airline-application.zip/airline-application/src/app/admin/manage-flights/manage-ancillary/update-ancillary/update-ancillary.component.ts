import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { State } from 'src/app/store/reducers/flight.reducer';
import { Flights } from 'src/app/models/flights.model';
import { FlightAncillaryServices } from 'src/app/models/flightAncillaryServices.model';
import * as fromApp from '../../../../store/reducers/app.reducer';
import * as FlightActions from '../../../../store/actions/flight.actions';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-update-ancillary',
  templateUrl: './update-ancillary.component.html',
  styleUrls: ['./update-ancillary.component.css']
})
export class UpdateAncillaryComponent implements OnInit {
  flights$: Observable<State>;
  submitted : boolean = false;
  selectedFlightId: string;
  selectedFlight: Flights;
  selectedAncillaryId : number;
  flightChanges: Flights;
  flightAncillaryService: FlightAncillaryServices;
  flightAncillaryServices : FlightAncillaryServices[];
  selectedAncillary : FlightAncillaryServices;
  updatedFlight: Flights;
  updatedAncillary : FlightAncillaryServices;

  constructor(private route : Router, private router : ActivatedRoute,
    private store : Store<fromApp.AppState>) { 
      this.flights$=this.store.select('flightState');
    }

  ngOnInit(): void {
    this.flights$.subscribe(
      (state : State) =>{
        this.selectedFlightId=state.currentFlightIdSelected;
      }
    )
    
    this.flights$.subscribe(
      (state : State) =>{
        this.selectedFlight = state.flights.filter(state => (state.id === this.selectedFlightId))[0];
      });

    this.flights$.subscribe(
      (state : State) =>{
        this.selectedAncillaryId = state.currentAncillaryIdSelected;
      }
    )

    this.selectedAncillary = this.selectedFlight.ancillaryServices.filter(ancillary => ancillary.serviceId === this.selectedAncillaryId)[0];
  }

  onSubmit(form : NgForm){
    this.submitted=true;
    this.flightChanges = new Flights();
    this.flightChanges.id = this.selectedFlightId;
    this.flightAncillaryService = new FlightAncillaryServices();
    this.flightAncillaryServices = this.selectedFlight.ancillaryServices.filter(ancillary =>ancillary.serviceId !== this.selectedAncillaryId);
    this.flightAncillaryService.serviceId = this.selectedAncillary.serviceId;
    this.flightAncillaryService.serviceName = form.value.name;
    this.flightAncillaryService.serviceCost = form.value.cost;
    this.flightAncillaryService.serviceDesc = form.value.desc;
    this.flightAncillaryServices.push(this.flightAncillaryService);
    this.flightChanges.ancillaryServices =this.flightAncillaryServices;
   
    this.store.dispatch(new FlightActions.UpdateAncillaryInFlight(this.flightChanges));

    this.flights$.subscribe((state : State)=>{
      this.updatedFlight = state.flights.filter(state => (state.id === this.selectedFlightId))[0];
    })
    this.updatedAncillary = this.updatedFlight.ancillaryServices.filter(ancillary =>(ancillary.serviceId === this.selectedAncillaryId))[0];
      
      form.reset();
  }
}
