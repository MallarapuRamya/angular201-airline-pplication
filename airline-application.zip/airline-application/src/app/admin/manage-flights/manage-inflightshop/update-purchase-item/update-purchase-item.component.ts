import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { State } from 'src/app/store/reducers/flight.reducer';
import { Flights } from 'src/app/models/flights.model';
import * as fromApp from '../../../../store/reducers/app.reducer';
import * as FlightActions from "../../../../store/actions/flight.actions";
import { FlightPurchases } from 'src/app/models/flightpurchases.model';

@Component({
  selector: 'app-update-purchase-item',
  templateUrl: './update-purchase-item.component.html',
  styleUrls: ['./update-purchase-item.component.css']
})
export class UpdatePurchaseItemComponent implements OnInit {

  submitted : boolean = false;
  flights$: Observable<State>;
  selectedFlightId: string;
  selectedFlight: Flights;
  flightChanges: Flights;
  flightPurchase : FlightPurchases;
  flightPurchases : FlightPurchases[];
  updatedFlight: Flights;
  selectedPurchase: FlightPurchases;
  selectedPurchaseId: number;

  constructor(private route : Router, private router : ActivatedRoute,
    private store : Store<fromApp.AppState>) { 
      this.flights$=this.store.select('flightState');
      }

    ngOnInit(): void {

      this.flights$.subscribe(
        (state : State) =>{
          this.selectedFlightId=state.currentFlightIdSelected;
        }
      )
      
      this.flights$.subscribe(
        (state : State) =>{
          this.selectedFlight = state.flights.filter(state => (state.id === this.selectedFlightId))[0];
        });
  
        this.flights$.subscribe(
          (state : State) =>{
            this.selectedPurchaseId = state.currentPurchaseIdSelected
          }
        );

        this.selectedPurchase = this.selectedFlight.inFlightShop.filter(purchase => purchase.purchaseId === this.selectedPurchaseId)[0];
    }

    onSubmit(form : NgForm){
      this.submitted=true;
      this.flightChanges = new Flights();
      this.flightChanges.id = this.selectedFlightId;
      this.flightPurchase = new FlightPurchases();
      this.flightPurchases = this.selectedFlight.inFlightShop.filter(purchase =>purchase.purchaseId !== this.selectedPurchaseId);
      this.flightPurchase.purchaseId = this.selectedPurchase.purchaseId;
      this.flightPurchase.purchaseItem = form.value.name;
      this.flightPurchase.purchaseCost = form.value.cost;
      this.flightPurchase.purchaseDesc = form.value.desc;
      this.flightPurchases.push(this.flightPurchase);
      this.flightChanges.inFlightShop =this.flightPurchases;
  
      this.store.dispatch(new FlightActions.UpdateAncillaryInFlight(this.flightChanges));
  
      this.flights$.subscribe((state : State)=>{
        this.updatedFlight = state.flights.filter(state => (state.id === this.selectedFlightId))[0];
      })
        form.reset();
    }
}

