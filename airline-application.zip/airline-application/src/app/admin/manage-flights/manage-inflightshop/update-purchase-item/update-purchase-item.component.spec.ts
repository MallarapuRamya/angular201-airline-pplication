import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatePurchaseItemComponent } from './update-purchase-item.component';
import { RouterTestingModule } from '@angular/router/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { StoreModule } from '@ngrx/store';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { NgModule } from '@angular/core';

describe('UpdatePurchaseItemComponent', () => {
  let component: UpdatePurchaseItemComponent;
  let fixture: ComponentFixture<UpdatePurchaseItemComponent>;
  let store  : MockStore;
  const initialState = {
    flights:[]=[],
    loading :false,
    loaded : false,
    currentFlightIdSelected : null,
    currentAncillaryIdSelected : null,
    currentMealIdSelected : null,
    currentPurchaseIdSelected : null
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatePurchaseItemComponent ],
      imports : [RouterTestingModule, FormsModule,MatCardModule,NgModule],
      providers : [provideMockStore({ initialState }), StoreModule.forRoot({})]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatePurchaseItemComponent);
    component = fixture.componentInstance;
    store = TestBed.inject(MockStore);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
