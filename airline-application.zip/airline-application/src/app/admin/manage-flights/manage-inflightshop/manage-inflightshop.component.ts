import { Component, OnInit } from '@angular/core';
import { State } from 'src/app/store/reducers/flight.reducer';
import { Observable } from 'rxjs';
import { Flights } from 'src/app/models/flights.model';
import { Router, ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import { FlightPurchases } from 'src/app/models/flightpurchases.model';
import * as fromApp from '../../../store/reducers/app.reducer';
import * as FlightActions from '../../../store/actions/flight.actions';



@Component({
  selector: 'app-manage-inflightshop',
  templateUrl: './manage-inflightshop.component.html',
  styleUrls: ['./manage-inflightshop.component.css']
})
export class ManageInflightshopComponent implements OnInit {
  flights$: Observable<State>;
  selectedFlightId: string;
  selectedFlight: Flights;
  selectedPurchaseId: number;
  flightChanges: Flights;
  flightPurchases: FlightPurchases[];
  updatedFlight: Flights;

  constructor(private route : Router, private router : ActivatedRoute,
    private store : Store<fromApp.AppState>) { 

      this.flights$=this.store.select('flightState');
    }

  ngOnInit(): void {

      this.flights$.subscribe(
        (state : State) =>{
          this.selectedFlightId=state.currentFlightIdSelected;
        }
      )
      
      this.flights$.subscribe(
        (state : State) =>{
          this.selectedFlight = state.flights.filter(state => (state.id === this.selectedFlightId))[0];
        });
    }

    onAdd()
    {
       this.route.navigate(['../add-purchase'], {relativeTo : this.router});
    }
    onUpdate(id : number){
      this.store.dispatch(new FlightActions.CurrentPurchaseIdSelected(id));
      this.route.navigate(['../update-purchase'], {relativeTo : this.router});
    }
    onDelete(id : number){
      this.store.dispatch(new FlightActions.CurrentPurchaseIdSelected(id));

      this.flights$.subscribe(
        (state : State) =>{
          this.selectedPurchaseId = state.currentPurchaseIdSelected;
        });
        this.flightChanges = new Flights();
        this.flightChanges.id = this.selectedFlightId;
        this.flightPurchases = this.selectedFlight.inFlightShop.filter(purchase => purchase.purchaseId !== this.selectedPurchaseId);
        this.flightChanges.inFlightShop=this.flightPurchases;
      
      this.store.dispatch(new FlightActions.UpdateAncillaryInFlight(this.flightChanges));
  
      this.flights$.subscribe((state : State) =>{
        this.updatedFlight = state.flights.filter( state =>(state.id === this.selectedFlightId))[0];
      })

      this.route.navigate(['../delete-ancillary'], {relativeTo : this.router});
    }
    onLogout(){

      localStorage.removeItem("session");
      this.route.navigate(['']);
    } 
}
