import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPurchaseItemComponent } from './add-purchase-item.component';
import { RouterTestingModule } from '@angular/router/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { StoreModule } from '@ngrx/store';
import { FlightMeals } from '../../../../models/flightMeals.model'
import { FormsModule } from '@angular/forms';

describe('AddPurchaseItemComponent', () => {
  let component: AddPurchaseItemComponent;
  let fixture: ComponentFixture<AddPurchaseItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddPurchaseItemComponent ],
      imports : [RouterTestingModule, FormsModule],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddPurchaseItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
