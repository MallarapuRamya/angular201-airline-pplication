import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { State } from 'src/app/store/reducers/flight.reducer';
import { Flights } from 'src/app/models/flights.model';
import * as fromApp from '../../../../store/reducers/app.reducer';
import * as FlightActions from "../../../../store/actions/flight.actions";
import { FlightPurchases } from 'src/app/models/flightpurchases.model';

@Component({
  selector: 'app-add-purchase-item',
  templateUrl: './add-purchase-item.component.html',
  styleUrls: ['./add-purchase-item.component.css']
})
export class AddPurchaseItemComponent implements OnInit {
  min : number = 1001;
  max : number = 2000;
  submitted : boolean = false;
  flights$: Observable<State>;
  selectedFlightId: string;
  selectedFlight: Flights;
  selectedPurchaseId: number;
  flightChanges: Flights;
  updatedFlight: Flights;
  flightPurchase: FlightPurchases;
  flightPurchases: FlightPurchases[];

  constructor(private route : Router, private router : ActivatedRoute,
    private store : Store<fromApp.AppState>) { 
      this.flights$=this.store.select('flightState');
    }

    ngOnInit(): void {

      this.flights$.subscribe(
        (state : State) =>{
          this.selectedFlightId=state.currentFlightIdSelected;
        }
      )
      
      this.flights$.subscribe(
        (state : State) =>{
          this.selectedFlight = state.flights.filter(state => (state.id === this.selectedFlightId))[0];
        });
  
        this.flights$.subscribe(
          (state : State) =>{
            this.selectedPurchaseId = state.currentPurchaseIdSelected;
          }
        )
    }

    getRandomNumberBetween(min : number,max : number){
      return Math.floor(Math.random()*(max-min+1)+min)
   }

    onSubmit(form : NgForm){
      this.submitted=true;
      this.flightChanges = new Flights();
      this.flightChanges.id = this.selectedFlightId;
      this.flightPurchase = new FlightPurchases();
      this.flightPurchases = [...this.selectedFlight.inFlightShop];
      this.flightPurchase.purchaseId = this.getRandomNumberBetween(this.min, this.max);
      this.flightPurchase.purchaseItem = form.value.name;
      this.flightPurchase.purchaseCost = form.value.cost;
      this.flightPurchase.purchaseDesc = form.value.desc;
      this.flightPurchases.push(this.flightPurchase);
      this.flightChanges.inFlightShop =this.flightPurchases;
  
      this.store.dispatch(new FlightActions.UpdateAncillaryInFlight(this.flightChanges));
  
      this.flights$.subscribe((state : State)=>{
        this.updatedFlight = state.flights.filter(state => (state.id === this.selectedFlightId))[0];
      })
        form.reset();
    }
}