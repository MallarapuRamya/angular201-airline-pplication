import { Component, OnInit } from '@angular/core';
import { State } from 'src/app/store/reducers/flight.reducer';
import { Observable } from 'rxjs';
import { Flights } from 'src/app/models/flights.model';
import { Router, ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import * as fromApp from '../../store/reducers/app.reducer';
import * as FlightActions from '../../store/actions/flight.actions';

@Component({
  selector: 'app-manage-flights',
  templateUrl: './manage-flights.component.html',
  styleUrls: ['./manage-flights.component.css']
})
export class ManageFlightsComponent implements OnInit {
 
  flights$ : Observable<State>;
  flights: Flights[];
  
  constructor(private route : Router, private router : ActivatedRoute,
    private store : Store<fromApp.AppState>) { 

      this.flights$=this.store.select('flightState');
    }

  ngOnInit(): void {
    
    this.getFlights();

    this.flights$.subscribe(
      (state : State) =>{
        this.flights=state.flights
      });
  }
  
  getFlights() {

    this.store.dispatch(new FlightActions.LoadFlights());
  }

  onAncillary( id : string){
    this.store.dispatch(new FlightActions.CurrentFlightIdSelected(id));
  }
  onManageMeals(id : string){
    this.store.dispatch(new FlightActions.CurrentFlightIdSelected(id));
  }
  onManageShop(id : string){
    this.store.dispatch(new FlightActions.CurrentFlightIdSelected(id));
  }
}
