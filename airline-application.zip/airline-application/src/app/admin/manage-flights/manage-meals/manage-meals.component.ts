import { Component, OnInit } from '@angular/core';
import { State } from 'src/app/store/reducers/flight.reducer';
import { Observable } from 'rxjs';
import { Flights } from 'src/app/models/flights.model';
import { Router, ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import { FlightMeals } from 'src/app/models/flightMeals.model';
import * as fromApp from '../../../store/reducers/app.reducer';
import * as FlightActions from '../../../store/actions/flight.actions';

@Component({
  selector: 'app-manage-meals',
  templateUrl: './manage-meals.component.html',
  styleUrls: ['./manage-meals.component.css']
})
export class ManageMealsComponent implements OnInit {
  flights$: Observable<State>;
  selectedFlightId: string;
  selectedFlight: Flights;
  selectedMealId: number;
  flightChanges: Flights;
  flightMeals: FlightMeals[];
  updatedFlight: Flights;

  constructor(private route : Router, private router : ActivatedRoute,
    private store : Store<fromApp.AppState>) { 

      this.flights$=this.store.select('flightState');
    }

  ngOnInit(): void {

      this.flights$.subscribe(
        (state : State) =>{
          this.selectedFlightId=state.currentFlightIdSelected;
        }
      )
      
      this.flights$.subscribe(
        (state : State) =>{
          this.selectedFlight = state.flights.filter(state => (state.id === this.selectedFlightId))[0];
        });
  }

  onAdd()
  {
     this.route.navigate(['../add-meals'], {relativeTo : this.router});
  }
  onUpdate(id : number){
    this.store.dispatch(new FlightActions.CurrentMealIdSelected(id));
    this.route.navigate(['../update-meals'], {relativeTo : this.router});
  }
  onDelete(id : number){
    this.store.dispatch(new FlightActions.CurrentMealIdSelected(id));
    this.flights$.subscribe(
      (state : State) =>{
        this.selectedMealId = state.currentMealIdSelected;
      });

      this.flightChanges = new Flights();
      this.flightChanges.id = this.selectedFlightId;
      this.flightMeals = this.selectedFlight.specialMeals.filter(meal => meal.mealId !== this.selectedMealId);
    this.flightChanges.specialMeals=this.flightMeals;
    
    this.store.dispatch(new FlightActions.UpdateAncillaryInFlight(this.flightChanges));

    this.flights$.subscribe((state : State) =>{
      this.updatedFlight = state.flights.filter( state =>(state.id === this.selectedFlightId))[0];
    })
    this.route.navigate(['../delete-ancillary'], {relativeTo : this.router});
  }

  onLogout(){

    localStorage.removeItem("session");
    this.route.navigate(['']);
  } 
  
}