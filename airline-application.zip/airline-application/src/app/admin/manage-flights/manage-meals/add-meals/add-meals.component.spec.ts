import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddMealsComponent } from './add-meals.component';
import { RouterTestingModule } from '@angular/router/testing';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { StoreModule } from '@ngrx/store';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';

describe('AddMealsComponent', () => {
  let component: AddMealsComponent;
  let fixture: ComponentFixture<AddMealsComponent>;
  
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddMealsComponent ],
      imports : [RouterTestingModule, FormsModule],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddMealsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
