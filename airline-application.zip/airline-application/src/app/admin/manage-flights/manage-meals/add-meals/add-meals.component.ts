import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { State } from 'src/app/store/reducers/flight.reducer';
import { Flights } from 'src/app/models/flights.model';
import { FlightMeals } from 'src/app/models/flightMeals.model';
import * as fromApp from '../../../../store/reducers/app.reducer';
import * as FlightActions from "../../../../store/actions/flight.actions";

@Component({
  selector: 'app-add-meals',
  templateUrl: './add-meals.component.html',
  styleUrls: ['./add-meals.component.css']
})
export class AddMealsComponent implements OnInit {
    min : number = 2001;
    max : number = 3000;
  submitted : boolean = false;
  flights$: Observable<State>;
  selectedFlightId: string;
  selectedFlight: Flights;
  selectedAncillaryId: number;
  flightChanges: Flights;
  flightMeal: FlightMeals;
  flightMeals: FlightMeals[];
  updatedFlight: Flights;

  constructor(private route : Router, private router : ActivatedRoute,
    private store : Store<fromApp.AppState>) { 

      this.flights$=this.store.select('flightState');
    }

    ngOnInit(): void {

      this.flights$.subscribe(
        (state : State) =>{
          this.selectedFlightId=state.currentFlightIdSelected;
        }
      )
      
      this.flights$.subscribe(
        (state : State) =>{
          this.selectedFlight = state.flights.filter(state => (state.id === this.selectedFlightId))[0];
        });
  
        this.flights$.subscribe(
          (state : State) =>{
            this.selectedAncillaryId = state.currentAncillaryIdSelected;
          }
        )
    }
    
    getRandomNumberBetween(min : number,max : number){
      return Math.floor(Math.random()*(max-min+1)+min)
   }

    onSubmit(form : NgForm){

      this.submitted=true;
      this.flightChanges = new Flights();
      this.flightChanges.id = this.selectedFlightId;
      this.flightMeal = new FlightMeals();
      this.flightMeals = [...this.selectedFlight.specialMeals];
      this.flightMeal.mealId = this.getRandomNumberBetween(this.min, this.max);
      this.flightMeal.mealName = form.value.name;
      this.flightMeal.mealCost = form.value.cost;
      this.flightMeal.mealDesc = form.value.desc;
      this.flightMeals.push(this.flightMeal);
      this.flightChanges.specialMeals =this.flightMeals;

      this.store.dispatch(new FlightActions.UpdateAncillaryInFlight(this.flightChanges));
  
      this.flights$.subscribe((state : State)=>{
        this.updatedFlight = state.flights.filter(state => (state.id === this.selectedFlightId))[0];
      })
        form.reset();
    }

}