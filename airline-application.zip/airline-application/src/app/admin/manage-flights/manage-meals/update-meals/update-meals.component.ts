import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { State } from 'src/app/store/reducers/flight.reducer';
import { Flights } from 'src/app/models/flights.model';
import { FlightMeals } from 'src/app/models/flightMeals.model';
import * as fromApp from '../../../../store/reducers/app.reducer';
import * as FlightActions from "../../../../store/actions/flight.actions";

@Component({
  selector: 'app-update-meals',
  templateUrl: './update-meals.component.html',
  styleUrls: ['./update-meals.component.css']
})
export class UpdateMealsComponent implements OnInit {

  submitted : boolean = false;
  flights$: Observable<State>;
  selectedFlightId: string;
  selectedFlight: Flights;
  flightChanges: Flights; 
  flightMeal: FlightMeals;
  flightMeals: FlightMeals[];
  updatedFlight: Flights;
  selectedMeals: FlightMeals;
  selectedMealId: number;

  constructor(private route : Router, private router : ActivatedRoute,
    private store : Store<fromApp.AppState>) { 
      this.flights$=this.store.select('flightState');
    }

    ngOnInit(): void {

      this.flights$.subscribe(
        (state : State) =>{
          this.selectedFlightId=state.currentFlightIdSelected;
        }
      )
      
      this.flights$.subscribe(
        (state : State) =>{
          this.selectedFlight = state.flights.filter(state => (state.id === this.selectedFlightId))[0];
        });
  
        this.flights$.subscribe(
          (state : State) =>{
            this.selectedMealId = state.currentMealIdSelected;
          }
        );

        this.selectedMeals = this.selectedFlight.specialMeals.filter(meal => meal.mealId === this.selectedMealId)[0];
    }

    onSubmit(form : NgForm){
      this.submitted=true;
      this.flightChanges = new Flights();
      this.flightChanges.id = this.selectedFlightId;
      this.flightMeal = new FlightMeals();
      this.flightMeals = this.selectedFlight.specialMeals.filter(meal =>meal.mealId !== this.selectedMealId);
      this.flightMeal.mealId = this.selectedMeals.mealId;
      this.flightMeal.mealName = form.value.name;
      this.flightMeal.mealCost = form.value.cost;
      this.flightMeal.mealDesc = form.value.desc;
      this.flightMeals.push(this.flightMeal);
      this.flightChanges.specialMeals =this.flightMeals;
  
      this.store.dispatch(new FlightActions.UpdateAncillaryInFlight(this.flightChanges));
  
      this.flights$.subscribe((state : State)=>{
        this.updatedFlight = state.flights.filter(state => (state.id === this.selectedFlightId))[0];
      })
        form.reset();
    }
}
