import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateMealsComponent } from './update-meals.component';
import { RouterTestingModule } from '@angular/router/testing';
import { StoreModule } from '@ngrx/store';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';

describe('UpdateMealsComponent', () => {
  let component: UpdateMealsComponent;
  let fixture: ComponentFixture<UpdateMealsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateMealsComponent ],
      imports : [RouterTestingModule,FormsModule],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateMealsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
}); 
