import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageMealsComponent } from './manage-meals.component';
import { RouterTestingModule } from '@angular/router/testing';
import { StoreModule } from '@ngrx/store';
import { ManageFlightsComponent } from '../manage-flights.component';
import { AdminComponent } from '../../admin.component';
import { Flights } from 'src/app/models/flights.model';
import { AppModule } from "../../../app.module";
import { FormsModule } from '@angular/forms';

describe('ManageMealsComponent', () => {
  let component: ManageMealsComponent;
  let fixture: ComponentFixture<ManageMealsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageMealsComponent, ManageFlightsComponent,AdminComponent],
      imports : [RouterTestingModule],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageMealsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

});
