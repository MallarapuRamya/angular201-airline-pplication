import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { AdminComponent } from './admin/admin.component';
import { StaffComponent } from './staff/staff.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatButtonModule} from '@angular/material/button';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatCardModule} from '@angular/material/card';
import {MatSelectModule} from '@angular/material/select';
import { SocialLoginComponent } from './shared/social-login/social-login.component';
import { FormsModule } from '@angular/forms';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import { StaffLandingComponent } from './staff/staff-landing/staff-landing.component';
import { SeatMapComponent } from './staff/seat-map/seat-map.component';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatDividerModule} from '@angular/material/divider';
import { SocialLoginModule , SocialAuthServiceConfig } from 'angularx-social-login';
import { GoogleLoginProvider, FacebookLoginProvider } from 'angularx-social-login';
import {MatCheckboxModule} from '@angular/material/checkbox';
import { StoreModule } from "@ngrx/store";
import { EffectsModule } from "@ngrx/effects";
import { FlightReducer } from './store/reducers/flight.reducer'
import { FlightEffects } from "./store/effects/flight.effects";
import { PassengerDetailsComponent } from './staff/passenger-details/passenger-details.component';
import {MatTableModule} from '@angular/material/table';
import { PassengerReducer } from "./store/reducers/passenger.reducer";
import { PassengerEffects } from "./store/effects/passenger.effects";
import { BookingDetailsComponent } from './staff/booking-details/booking-details.component';
import { EditAncillaryServicesComponent } from './staff/edit-ancillary-services/edit-ancillary-services.component';
import { ChekedInPassengersComponent } from './staff/cheked-in-passengers/cheked-in-passengers.component';
import { AdminLandingComponent } from './admin/admin-landing/admin-landing.component';
import { ManageFlightsComponent } from './admin/manage-flights/manage-flights.component';
import { ManagePassengersComponent } from './admin/manage-passengers/manage-passengers.component';
import { SeatReducer } from './store/reducers/seat.reducer'
import { SeatEffects } from './store/effects/seat.effects'
import { MatPaginatorModule } from '@angular/material/paginator';
import { AddPassengerComponent } from './admin/manage-passengers/add-passenger/add-passenger.component';
import { UpdatePassengerComponent } from './admin/manage-passengers/update-passenger/update-passenger.component';
import { ManageAncillaryComponent } from './admin/manage-flights/manage-ancillary/manage-ancillary.component';
import { AddAncillaryComponent } from './admin/manage-flights/manage-ancillary/add-ancillary/add-ancillary.component';
import { UpdateAncillaryComponent } from './admin/manage-flights/manage-ancillary/update-ancillary/update-ancillary.component';
import { DeleteAncillaryComponent } from './admin/manage-flights/manage-ancillary/delete-ancillary/delete-ancillary.component';
import { ManageMealsComponent } from './admin/manage-flights/manage-meals/manage-meals.component';
import { AddMealsComponent } from './admin/manage-flights/manage-meals/add-meals/add-meals.component';
import { UpdateMealsComponent } from './admin/manage-flights/manage-meals/update-meals/update-meals.component';
import { ManageInflightshopComponent } from './admin/manage-flights/manage-inflightshop/manage-inflightshop.component';
import { AddPurchaseItemComponent } from './admin/manage-flights/manage-inflightshop/add-purchase-item/add-purchase-item.component';
import { UpdatePurchaseItemComponent } from './admin/manage-flights/manage-inflightshop/update-purchase-item/update-purchase-item.component';
import { PageNotFoundComponent } from './shared/page-not-found/page-not-found.component';
import { NavBarComponent } from './shared/nav-bar/nav-bar.component';
import { AdminNavBarComponent } from './shared/admin-nav-bar/admin-nav-bar.component';
import {MatTabsModule} from '@angular/material/tabs';
import {MatIconModule} from '@angular/material/icon';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { FlightDetailsComponent } from './staff/flight-details/flight-details.component';
import { CheckInComponent } from './staff/check-in/check-in.component';
import { InFlightDetailsComponent } from './staff/in-flight-details/in-flight-details.component';
import { InFlightComponent } from './staff/in-flight/in-flight.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { ChangeSeatComponent } from '../app/staff/change-seat/change-seat.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    AdminComponent,
    StaffComponent,
    SocialLoginComponent,
    StaffLandingComponent,
    SeatMapComponent,
    PassengerDetailsComponent,
    BookingDetailsComponent,
    EditAncillaryServicesComponent,
    ChekedInPassengersComponent,
    AdminLandingComponent,
    ManageFlightsComponent,
    ManagePassengersComponent,
    AddPassengerComponent,
    UpdatePassengerComponent,
    ManageAncillaryComponent,
    AddAncillaryComponent,
    UpdateAncillaryComponent,
    DeleteAncillaryComponent,
    ManageMealsComponent,
    AddMealsComponent,
    UpdateMealsComponent,
    ManageInflightshopComponent,
    AddPurchaseItemComponent,
    UpdatePurchaseItemComponent,
    PageNotFoundComponent,
    NavBarComponent,
    AdminNavBarComponent,
    FlightDetailsComponent,
    CheckInComponent,
    InFlightDetailsComponent,
    InFlightComponent,
    ChangeSeatComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatButtonModule,
    MatCardModule,
    MatFormFieldModule,
    MatSelectModule,
    FormsModule,
    MatInputModule,
    HttpClientModule,
    MatGridListModule,
    MatDividerModule,
    SocialLoginModule,
    MatCheckboxModule,
    MatIconModule,
    MatTableModule,
    MatTabsModule,
    MatPaginatorModule,
    MatSlideToggleModule,
    StoreModule.forRoot( {flightState : FlightReducer, passengerState : PassengerReducer, seatState : SeatReducer}),
    EffectsModule.forRoot([FlightEffects, PassengerEffects, SeatEffects]),
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production })
  ],
  providers: [
    {
      provide : 'SocialAuthServiceConfig',
      useValue :{
        autoLogin : false,
        providers : [
          {
            id : GoogleLoginProvider.PROVIDER_ID,
            provider : new GoogleLoginProvider('782244290662-5197p2jt39tti83dfu855jvr457h70ui.apps.googleusercontent.com'),
          },
          {
            id: FacebookLoginProvider.PROVIDER_ID,
            provider: new FacebookLoginProvider('280251859746500'),
          },
        ],
      } as SocialAuthServiceConfig,
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }