import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-in-flight',
  templateUrl: './in-flight.component.html',
  styleUrls: ['./in-flight.component.css']
})
export class InFlightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
