import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditAncillaryServicesComponent } from './edit-ancillary-services.component';
import { RouterTestingModule } from '@angular/router/testing';
import { StoreModule } from '@ngrx/store';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MockStore, provideMockStore } from '@ngrx/store/testing';

describe('EditAncillaryServicesComponent', () => {
  let component: EditAncillaryServicesComponent;
  let fixture: ComponentFixture<EditAncillaryServicesComponent>;
  let store  : MockStore;
  
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditAncillaryServicesComponent],
      imports : [RouterTestingModule],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditAncillaryServicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
