import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { State } from 'src/app/store/reducers/flight.reducer';
import { PassengerState } from 'src/app/store/reducers/passenger.reducer';
import { Flights } from 'src/app/models/flights.model';
import { Passengers } from 'src/app/models/passengers.model';
import { NgForm } from '@angular/forms';
import * as fromApp from '../../store/reducers/app.reducer';
import * as PassengerActions from '../../store/actions/passenger.actions';


@Component({
  selector: 'app-edit-ancillary-services',
  templateUrl: './edit-ancillary-services.component.html',
  styleUrls: ['./edit-ancillary-services.component.css']
})
export class EditAncillaryServicesComponent implements OnInit {
  
  flights$: Observable<State>;
  passengers$: Observable<PassengerState>;
  selectedPassengerId : number;
  selectedPassenger: Passengers;
  passengerChanges: Passengers;
  isAddedAncillary : boolean = false;
  ancillaryServices : String[] = ["Extra 5kg Baggage","Fast Forward","Seat Plus"];
  meals : String[] = ["Vegetable Biryani","Chicken Biryani","Veg Noodles","Chicken Noodles","Veg Meal","Non-Veg Meal","Baby Meal"];
  shoppingItems : String[] = ["Branded Bag","Luxury Watch","Perfume","Gadgets"]
  
  constructor(private store : Store<fromApp.AppState>) { 

      this.flights$=this.store.select('flightState');
      this.passengers$ = this.store.select('passengerState');
      
    }

    ngOnInit(): void {
      
      this.passengers$.subscribe(
        (state : PassengerState) => {
          this.selectedPassengerId = state.currentPassengerIdSelected;
        });

        this.passengers$.subscribe(
          (state : PassengerState) =>{

            this.selectedPassenger= state.passengers.filter(state => (state.id === this.selectedPassengerId))[0];
          });

         }

    onSubmit( form : NgForm)
    {

      this.isAddedAncillary = true;
      this.passengerChanges = new Passengers();
      this.passengerChanges.id = this.selectedPassengerId;
      this.passengerChanges.ancillaryServices = form.value.services;
      this.passengerChanges.shopInFlight = form.value.items;
      this.passengerChanges.specialMeals = form.value.meals;
      this.store.dispatch(new PassengerActions.EditPassenger(this.passengerChanges));

    }  
}
