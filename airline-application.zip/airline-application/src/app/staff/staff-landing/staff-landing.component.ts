import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from "@ngrx/store";
import { Flights } from '../../models/flights.model';
import { SocialUser } from 'angularx-social-login';
import { Observable } from 'rxjs';
import { State } from 'src/app/store/reducers/flight.reducer';
import * as fromApp from '../../store/reducers/app.reducer'
import * as FlightActions from '../../store/actions/flight.actions'

@Component({
  selector: 'app-staff-landing',
  templateUrl: './staff-landing.component.html',
  styleUrls: ['./staff-landing.component.css']
})
export class StaffLandingComponent implements OnInit {

  user : SocialUser;
  loggedIn : boolean ;
  flights : Flights[];
  flights$ : Observable<State>;
  selectedValue: string;

  constructor(private route : Router, private router : ActivatedRoute, 
    private store : Store<fromApp.AppState>) { 

         this.flights$=this.store.select('flightState');
         
    }

  ngOnInit(): void {

    this.getFlights();

    this.flights$.subscribe(
      (state : State) =>(this.flights=state.flights)
    )
    
  }
  getFlights(){

  this.store.dispatch(new FlightActions.LoadFlights());

  }
  onListOfpassengers(){

    this.store.dispatch(new FlightActions.CurrentFlightIdSelected(this.selectedValue));
    this.route.navigate(['check-in'],{relativeTo : this.router})
  }
  OnChangeAncillaryService(){

    this.store.dispatch(new FlightActions.CurrentFlightIdSelected(this.selectedValue));
     this.route.navigate(['in-flight'],{relativeTo : this.router})
  }
}
