import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { PassengerState } from 'src/app/store/reducers/passenger.reducer';
import { Passengers } from 'src/app/models/passengers.model';
import { Router, ActivatedRoute } from '@angular/router';
import { State } from 'src/app/store/reducers/flight.reducer';
import { Seats } from "../../models/seats.model";
import { SeatState } from 'src/app/store/reducers/seat.reducer';
import * as fromApp from '../../store/reducers/app.reducer';
import * as SeatActions from '../../store/actions/seat.actions';
import * as PassengerActions from '../../store/actions/passenger.actions'
import { SeatsService } from 'src/app/shared/services/seats.service';
 
@Component({
  selector: 'app-seat-map',
  templateUrl: './seat-map.component.html',
  styleUrls: ['./seat-map.component.css']
})
export class SeatMapComponent implements OnInit {
  seats : string[]=["1A","1B","1C","1D","1E","1F",
                    "2A","2B","2C","2D","2E","2F",
                    "3A","3B","3C","3D","3E","3F",
                    "4A","4B","4C","4D","4E","4F"];
  servicesAvailable : string []=["infant","wheelchair"]
  selectedFlight : string;
  selectedPassengerDetails : Passengers;
  passengerChanges : Passengers;
  passengers : Passengers[]; 
  passengers$ : Observable<PassengerState>;
  seats$ : Observable<SeatState>
  flights$ : Observable<State>;
  selectedPassenger : number;
  selectedSeats : string[]=[];
  seat : Seats ;
  seatsReserved : string[] =[];
  seatsReservedInFlight : Seats;
  newSeatsReserved : Seats;
  updatedReservedSeats : Seats;
  selectedServices : string[]=[];
  newSelectedSeatsAndReservedSeats : string[]=[];
  selectedInfants : string[]=[];
  selectedSpecialMeals : string[]=[];
  selectedWheelChairs : string[]=[];
  infant : boolean = false;
  wheelchair : boolean = false;
  
  constructor( private store : Store<fromApp.AppState>,
    private route : Router , private router : ActivatedRoute, 
    private seatService : SeatsService) { 

    this.passengers$ = this.store.select('passengerState');
    this.flights$=this.store.select('flightState');
    this.seats$ = this.store.select('seatState')
  }

  ngOnInit(): void {

     this.flights$.subscribe(
      (state : State) => (this.selectedFlight=state.currentFlightIdSelected)); 

      this.getReservedSeats();
         
     this.passengers$.subscribe(
    (state : PassengerState) =>(this.selectedPassenger=state.currentPassengerIdSelected));

    this.passengers$.subscribe(
      (state : PassengerState) => {
       this.passengers=state.passengers;
       }); 

      for(let i in this.passengers)
      {
        if(this.passengers[i].id === this.selectedPassenger)
        {
          this.selectedPassengerDetails= this.passengers[i];
        }
      }

      this.seats$.subscribe((state : SeatState) =>{
        this.seatsReservedInFlight = state.reservedSeatsInFlight;
      }) 
     
  }

  onChange(event : any){
    let index = this.selectedSeats.indexOf(event.target.value);
     if(index == -1)
     {
        this.selectedSeats.push(event.target.value);
     }
     else{
       this.selectedSeats.splice(index, 1);
     }
  }

  reserveBooking(){
    this.passengerChanges = new Passengers();
    this.passengerChanges.id= this.selectedPassengerDetails.id;
    this.passengerChanges.flightId=this.selectedPassengerDetails.flightId;
    this.passengerChanges.name=this.selectedPassengerDetails.name;
    this.passengerChanges.passport=this.selectedPassengerDetails.passport;
    this.passengerChanges.age=this.selectedPassengerDetails.age;
    this.passengerChanges.gender = this.selectedPassengerDetails.gender;
    this.passengerChanges.dateOfBirth=this.selectedPassengerDetails.dateOfBirth;
    this.passengerChanges.address=this.selectedPassengerDetails.address;
    this.passengerChanges.specialMeals = this.selectedPassengerDetails.specialMeals;
    this.passengerChanges.infants=this.infant;
    this.passengerChanges.wheelchair=this.wheelchair;
    this.passengerChanges.ancillaryServices=this.selectedPassengerDetails.ancillaryServices;
    this.passengerChanges.shopInFlight=this.selectedPassengerDetails.shopInFlight;
    this.passengerChanges.seatNumber=this.selectedSeats;
    this.passengerChanges.isCheckedIn=true;
  
    this.store.dispatch(new PassengerActions.EditPassengerSeatsAndAncillary(this.passengerChanges));
  }

  updateReservedSeatsInFlight(){ 
    this.updateServicesReservedForSeatInFlight();
       this.newSeatsReserved=new Seats();
       this.newSelectedSeatsAndReservedSeats=[...this.seatsReservedInFlight.reservedSeats];
       this.newSelectedSeatsAndReservedSeats=this.newSelectedSeatsAndReservedSeats.concat(this.selectedSeats);
       this.newSeatsReserved.id=this.selectedFlight;
       this.newSeatsReserved.reservedSeats=this.newSelectedSeatsAndReservedSeats;
       this.newSeatsReserved.infants=this.selectedInfants.concat(this.seatsReservedInFlight.infants);
       this.newSeatsReserved.wheelchairs=this.selectedWheelChairs.concat(this.seatsReservedInFlight.wheelchairs);
  
      this.store.dispatch(new SeatActions.ReserveSeats(this.newSeatsReserved));
      
  }

  updateServicesReservedForSeatInFlight()
  {
    for(let i in this.selectedServices)
    if(this.selectedServices[i] === "infant")
    {
      this.selectedInfants=this.selectedSeats;
      this.infant=true;
    }
    else if(this.selectedServices[i] === "wheelchair"){
      this.selectedWheelChairs=this.selectedSeats;
      this.wheelchair=true; 
    }
  }

  onSelectServices(event : any)
  {
    let index = this.selectedServices.indexOf(event.target.value);
    if(index == -1)
    {
       this.selectedServices.push(event.target.value);
    }
    else{
      this.selectedServices.splice(index, 1);
    }

  }

  getStylesClass(seat : string){
       for(let i in this.seatsReservedInFlight.infants){
         if(this.seatsReservedInFlight.infants[i] === seat){
             return 'infants'
         }
       }

        for(let i in this.seatsReservedInFlight.wheelchairs){
          if(this.seatsReservedInFlight.wheelchairs[i] === seat){
              return 'wheelchair'
          }
      }
  }

  disablingAlreadyReservedSeats(seat : string)
    {
      for(let i in this.seatsReservedInFlight.reservedSeats)
      {
        if(this.seatsReservedInFlight.reservedSeats[i] === seat)
        {
          return true;
        }
      }
    }

    getReservedSeats(){

      this.store.dispatch(new SeatActions.LoadSeatsByFlightId(this.selectedFlight));
    }

  onBook()
  {
    this.updateReservedSeatsInFlight();
   this.reserveBooking();
   this.route.navigate(['../booking-details'], {relativeTo : this.router});
  }

}
