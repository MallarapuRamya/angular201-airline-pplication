import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChekedInPassengersComponent } from './cheked-in-passengers.component';
import { RouterTestingModule } from '@angular/router/testing';
import { StoreModule } from '@ngrx/store';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';

describe('ChekedInPassengersComponent', () => {
  let component: ChekedInPassengersComponent;
  let fixture: ComponentFixture<ChekedInPassengersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChekedInPassengersComponent ],
      imports : [RouterTestingModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChekedInPassengersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
