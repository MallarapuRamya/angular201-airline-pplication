import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { State } from 'src/app/store/reducers/flight.reducer';
import { PassengerState } from 'src/app/store/reducers/passenger.reducer';
import { Passengers } from 'src/app/models/passengers.model';
import { SeatState } from 'src/app/store/reducers/seat.reducer';
import {MatTableDataSource } from '@angular/material/table';
import { Seats } from 'src/app/models/seats.model';
import * as PassengerActions from "../../store/actions/passenger.actions";
import * as fromApp from '../../store/reducers/app.reducer';
import * as SeatActions from '../../store/actions/seat.actions';



@Component({
  selector: 'app-cheked-in-passengers',
  templateUrl: './cheked-in-passengers.component.html',
  styleUrls: ['./cheked-in-passengers.component.css']
})
export class ChekedInPassengersComponent implements OnInit {

  passengers : Passengers[]=[];
  filteredPassengers : Passengers[]=[];
  selectedFlightId : string ;
  flights$ : Observable<State>;
  passengers$ : Observable<PassengerState>;
  passengerChanges : Passengers;
  selectedPassenger: Passengers;
  seats$: Observable<SeatState>;
  reservedSeats: Seats;
  seats: Seats;
  displayedColumns: string[] = ['PassengerId','PassengerName','Passport' ,'SeatNumber','AncillaryServices','ShoppingItems','SpecialMeals','Actions'];
  dataSource : any;
  

  constructor(private route : Router,private router : ActivatedRoute,
    private store : Store<fromApp.AppState>) { 

      this.flights$=this.store.select('flightState');
      this.passengers$ = this.store.select('passengerState');
      this.seats$ = this.store.select('seatState');
      
    }

  ngOnInit(): void {
    this.getPassengers();
    
  this.flights$.subscribe(
    (state : State) =>{

      this.selectedFlightId=state.currentFlightIdSelected;
    }
    );
    
    this.getSeats();

  this.passengers$.subscribe(
    (state : PassengerState) => {
      this.passengers = state.passengers;
     this.filteredPassengers= state.passengers.filter(state => (state.flightId === this.selectedFlightId))
     this.dataSource = new MatTableDataSource(this.filteredPassengers);
    
     });  

     this.seats$.subscribe(
      (state : SeatState) => {
        this.reservedSeats = state.reservedSeatsInFlight;
      }
    )
  }

  getPassengers()
  { 
    this.store.dispatch(new PassengerActions.LoadPassengers());
  }

  getSeats()
  {
    this.store.dispatch(new SeatActions.LoadSeatsByFlightId(this.selectedFlightId));
  }
  
  onUpdateServices(row : Passengers){

      this.store.dispatch(new PassengerActions.CurrentPassengerIdSelected(row.id));
      this.route.navigate(['../edit-ancillary'], {relativeTo : this.router});
    }
    
}
