import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { PassengerState } from 'src/app/store/reducers/passenger.reducer';
import { SeatState } from 'src/app/store/reducers/seat.reducer';
import { State } from 'src/app/store/reducers/flight.reducer';
import { Passengers } from 'src/app/models/passengers.model';
import * as fromApp from '../../store/reducers/app.reducer';
import { Seats } from 'src/app/models/seats.model';
import { Flights } from 'src/app/models/flights.model';

@Component({
  selector: 'app-booking-details',
  templateUrl: './booking-details.component.html',
  styleUrls: ['./booking-details.component.css']
})
export class BookingDetailsComponent implements OnInit {

  passengers$ : Observable<PassengerState>;
  seats$ : Observable<SeatState>
  flights$ : Observable<State>;
  bookingDetailsOfPassenger : Passengers ;
  selectedPassenger : number ;
  seatsReservedInFlight : Seats;
  flight : Flights;
  seatType : string;
  
  constructor(private store : Store<fromApp.AppState>,
    private route : Router , private router : ActivatedRoute) {
      this.passengers$ = this.store.select('passengerState');
      this.flights$=this.store.select('flightState');
      this.seats$ = this.store.select('seatState');
     }

  ngOnInit(): void {

    this.passengers$.subscribe(
      (state : PassengerState) =>(this.selectedPassenger=state.currentPassengerIdSelected));

      this.passengers$.subscribe(
        (state : PassengerState) => {
          
         this.bookingDetailsOfPassenger=state.passengers.filter(state => (state.id === this.selectedPassenger))[0];
         });

      this.flights$.subscribe(
            (state : State) =>
            {
              this.flight= state.flights.filter(state =>(state.id === this.bookingDetailsOfPassenger.flightId))[0];
            });
  }

}
