import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { PassengerState } from 'src/app/store/reducers/passenger.reducer';
import { Passengers } from 'src/app/models/passengers.model';
import { Router, ActivatedRoute } from '@angular/router';
import { State } from 'src/app/store/reducers/flight.reducer';
import { Flights } from 'src/app/models/flights.model';
import { Seats } from "../../models/seats.model";
import { SeatState } from 'src/app/store/reducers/seat.reducer';
import * as fromApp from '../../store/reducers/app.reducer';
import * as SeatActions from '../../store/actions/seat.actions';
import * as PassengerActions from '../../store/actions/passenger.actions'

@Component({
  selector: 'app-flight-details',
  templateUrl: './flight-details.component.html',
  styleUrls: ['./flight-details.component.css']
})
export class FlightDetailsComponent implements OnInit {
 
  seats : string[]=["1A","1B","1C","1D","1E","1F",
                    "2A","2B","2C","2D","2E","2F",
                    "3A","3B","3C","3D","3E","3F",
                    "4A","4B","4C","4D","4E","4F"];
  servicesAvailable : string []=["SpecialMeals","infant","wheelchair"]
  selectedFlight : string;
  passengerChanges : Passengers;
  passenger : Passengers;
  flight : Flights;
  passengers : Passengers[]; 
  passengers$ : Observable<PassengerState>;
  seats$ : Observable<SeatState>
  flights$ : Observable<State>;
  selectedSeats : string[]=[];
  seatsReservedInFlight : Seats;
  seatsChanges : Seats
  isUndoCheckIn : boolean = false;
  seatNum : string;
  
  constructor( private store : Store<fromApp.AppState>,
    private route : Router , private router : ActivatedRoute) { 

    this.passengers$ = this.store.select('passengerState');
    this.flights$=this.store.select('flightState');
    this.seats$ = this.store.select('seatState')
  }

  ngOnInit(): void {

     this.flights$.subscribe(
      (state : State) => {

        this.selectedFlight=state.currentFlightIdSelected;
        this.flight = state.flights.filter( flight => flight.id === this.selectedFlight)[0];
      }); 


      this.getReservedSeats();

    this.passengers$.subscribe(
      (state : PassengerState) => {
       this.passengers=state.passengers.filter( passenger => passenger.flightId === this.selectedFlight);
       }); 

      this.seats$.subscribe((state : SeatState) =>{
        this.seatsReservedInFlight = state.reservedSeatsInFlight;
      }) 
     
  }

  onChange(event : any){
    let index = this.selectedSeats.indexOf(event.target.value);
     if(index == -1)
     {
        this.selectedSeats.push(event.target.value);
     }
     else{
       this.selectedSeats.splice(index, 1);
     }
  }


  getStylesClass(seat : string){
       for(let i in this.seatsReservedInFlight.infants){
         if(this.seatsReservedInFlight.infants[i] === seat){
             return 'infants'
         }
       }

        for(let i in this.seatsReservedInFlight.wheelchairs){
          if(this.seatsReservedInFlight.wheelchairs[i] === seat){
              return 'wheelchair'
          }
      }
  }
  disablingAlreadyReservedSeats(seat : string)
    {
      for(let i in this.seatsReservedInFlight.reservedSeats)
      {
        if(!this.isUndoCheckIn){
          return true;
        }
        if(this.seatsReservedInFlight.reservedSeats[i] === seat)
        {
          return false;
        }
      }
      return true;
    }

    getSeatsAlreadyReserved(seat : string){
     
      for(let i in this.seatsReservedInFlight.reservedSeats){
          if(this.seatsReservedInFlight.reservedSeats[i] === seat){
            return 'true'
          }
      }
    }

    getReservedSeats(){

      this.store.dispatch(new SeatActions.LoadSeatsByFlightId(this.selectedFlight));
    }

   onUndoCheckIn()
  {
    this.isUndoCheckIn = true; 
  }

  onUndoBooking(){
    this.seatNum = this.selectedSeats[0];
    this.passenger = this.passengers.filter( passenger => passenger.seatNumber[0] === this.seatNum)[0];
    this.passengerChanges = new Passengers();
    this.seatsChanges  = new Seats();

    this.passengerChanges.id = this.passenger.id;
    this.passengerChanges.isCheckedIn = false;
    this.passengerChanges.wheelchair = false;
    this.passengerChanges.infants = false;
    this.passengerChanges.seatNumber = [];
    this.store.dispatch(new PassengerActions.EditPassenger(this.passengerChanges));

    this.seatsChanges.id = this.seatsReservedInFlight.id;
    this.seatsChanges.reservedSeats = this.seatsReservedInFlight.reservedSeats.filter(seat => seat !== this.seatNum);
    this.seatsChanges.infants = this.seatsReservedInFlight.infants.filter(seat => seat !== this.seatNum);
    this.seatsChanges.wheelchairs = this.seatsReservedInFlight.wheelchairs.filter(seat => seat !== this.seatNum);

    this.store.dispatch(new SeatActions.ReserveSeats(this.seatsChanges));
    this.isUndoCheckIn = false;
  }
  onCancel(){
    this.isUndoCheckIn = false;
  }
}

