import { Component, OnInit } from '@angular/core';
import { Passengers } from 'src/app/models/passengers.model';
import { Seats } from 'src/app/models/seats.model';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from "@ngrx/store";
import { Observable } from 'rxjs';
import { State } from 'src/app/store/reducers/flight.reducer';
import { PassengerState } from 'src/app/store/reducers/passenger.reducer'
import { SeatState } from 'src/app/store/reducers/seat.reducer';
import * as fromApp from '../../store/reducers/app.reducer'
import * as PassengerActions from "../../store/actions/passenger.actions";
import * as SeatActions from '../../store/actions/seat.actions';
import { SeatsService } from 'src/app/shared/services/seats.service';



@Component({
  selector: 'app-passenger-details',
  templateUrl: './passenger-details.component.html',  
  styleUrls: ['./passenger-details.component.css']
})
export class PassengerDetailsComponent implements OnInit {

passengers : Passengers[]=[];
filteredPassengers : Passengers[]=[];
passenger : Passengers;
selectedFlight : string ;
flights$ : Observable<State>;
passengers$ : Observable<PassengerState>;
seats$: Observable<SeatState>;
seatsReservedInFlight: Seats;
seatNum : string;
filterValues : string[]=["Please select","Checked-in","Not Checked-in","Wheelchair","Infant","Clear selection"];
selectedValue: string = "Please select";


  constructor( private route : Router,private router : ActivatedRoute,
    private store : Store<fromApp.AppState>, private seatService : SeatsService) { 

      this.flights$=this.store.select('flightState');
      this.passengers$ = this.store.select('passengerState');
      this.seats$ = this.store.select('seatState')
  }

  ngOnInit(): void {
  
    this.getPassengers();


  this.flights$.subscribe(
    (state : State) =>(this.selectedFlight=state.currentFlightIdSelected));

  this.passengers$.subscribe(
    (state : PassengerState) => {
      
     this.passengers= state.passengers.filter(state => (state.flightId === this.selectedFlight));
     this.filteredPassengers = this.passengers;
     });

    this.getReservedSeats();

     this.seats$.subscribe((state : SeatState) =>{
      this.seatsReservedInFlight = state.reservedSeatsInFlight;
    })
    
  } 
  getReservedSeats(){

    this.store.dispatch(new SeatActions.LoadSeatsByFlightId(this.selectedFlight));
  }

  getPassengers()
  {
    this.store.dispatch(new PassengerActions.LoadPassengers());
  }

  onCheckIn(id : number){

     this.store.dispatch(new PassengerActions.CurrentPassengerIdSelected(id)); 
     this.route.navigate(['../seat-map'],{relativeTo : this.router});
  }
  onUndoCheckIn(id : number){

   let passengerChanges : Passengers= new Passengers();
   let seatsChanges : Seats = new Seats();
    this.passenger = this.passengers.filter(passenger => passenger.id === id)[0];
    this.seatNum = this.passenger.seatNumber[0];
    passengerChanges.id = this.passenger.id;
    passengerChanges.isCheckedIn = false;
    passengerChanges.wheelchair = false;
    passengerChanges.infants = false;
    passengerChanges.seatNumber = [];
    this.store.dispatch(new PassengerActions.EditPassenger(passengerChanges)); 

    
    seatsChanges.id = this.seatsReservedInFlight.id;
    seatsChanges.reservedSeats = this.seatsReservedInFlight.reservedSeats.filter(seat => seat !== this.seatNum);
    seatsChanges.infants = this.seatsReservedInFlight.infants.filter(seat => seat !== this.seatNum);
    seatsChanges.wheelchairs = this.seatsReservedInFlight.wheelchairs.filter(seat => seat !== this.seatNum);

    this.store.dispatch(new SeatActions.ReserveSeats(seatsChanges));
  }

  onChangeSeat(id : number){  
    this.store.dispatch(new PassengerActions.CurrentPassengerIdSelected(id)); 
    this.route.navigate(['../change-seat'],{relativeTo : this.router});
  }
  onChange(event : any){
    
    switch(event.value){
      case 'Checked-in' :
        this.filteredPassengers = this.passengers.filter(passenger => passenger.isCheckedIn);
        break;
      case 'Not Checked-in' :
          this.filteredPassengers = this.passengers.filter(passenger => !passenger.isCheckedIn);
          break;
      case 'Wheelchair' :
        this.filteredPassengers = this.passengers.filter(passenger => passenger.wheelchair);
        break;
      case 'Infant' :
        this.filteredPassengers = this.passengers.filter(passenger => passenger.infants);
          break;
      case  'Clear selection' : 
        this.filteredPassengers = this.passengers;
        this.selectedValue = "Please select";
        break ;
      case 'default' :
        break;
    }
  }

  }