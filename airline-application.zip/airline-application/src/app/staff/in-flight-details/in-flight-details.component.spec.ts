import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InFlightDetailsComponent } from './in-flight-details.component';

describe('InFlightDetailsComponent', () => {
  let component: InFlightDetailsComponent;
  let fixture: ComponentFixture<InFlightDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InFlightDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InFlightDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
