import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { PassengerState } from 'src/app/store/reducers/passenger.reducer';
import { Passengers } from 'src/app/models/passengers.model';
import { Router, ActivatedRoute } from '@angular/router';
import { State } from 'src/app/store/reducers/flight.reducer';
import { Flights } from 'src/app/models/flights.model';
import { Seats } from "../../models/seats.model";
import { SeatState } from 'src/app/store/reducers/seat.reducer';
import * as fromApp from '../../store/reducers/app.reducer';
import * as SeatActions from '../../store/actions/seat.actions';
import * as PassengerActions from '../../store/actions/passenger.actions'

@Component({
  selector: 'app-in-flight-details',
  templateUrl: './in-flight-details.component.html',
  styleUrls: ['./in-flight-details.component.css']
})
export class InFlightDetailsComponent implements OnInit {
 
  seats : string[]=["1A","1B","1C","1D","1E","1F",
                    "2A","2B","2C","2D","2E","2F",
                    "3A","3B","3C","3D","3E","3F",
                    "4A","4B","4C","4D","4E","4F"];
  servicesAvailable : string[]=["SpecialMeals","infant","wheelchair"]
  selectedFlight : string;
  passengerChanges : Passengers;
  passenger : Passengers;
  flight : Flights;
  passengers : Passengers[]; 
  passengers$ : Observable<PassengerState>;
  seats$ : Observable<SeatState>
  flights$ : Observable<State>;
  selectedSeats : string[]=[];
  seatsReservedInFlight : Seats;
  seatsChanges : Seats
  isUndoCheckIn : boolean = false;
  seatNum : string;
  passengersOptedSpecialmeals : Passengers[] = [];
  seatsWithSpecialMeals : String[] = [];
  
  constructor( private store : Store<fromApp.AppState>,
    private route : Router , private router : ActivatedRoute) { 

    this.passengers$ = this.store.select('passengerState');
    this.flights$=this.store.select('flightState');
    this.seats$ = this.store.select('seatState')
  }

  ngOnInit(): void {

     this.flights$.subscribe(
      (state : State) => {

        this.selectedFlight=state.currentFlightIdSelected;
        this.flight = state.flights.filter( flight => flight.id === this.selectedFlight)[0];
      }); 

    this.passengers$.subscribe(
      (state : PassengerState) => {
       this.passengers=state.passengers.filter( passenger => passenger.flightId === this.selectedFlight);
       this.passengersOptedSpecialmeals = this.passengers.filter( passenger => passenger.specialMeals.length>0);
       }); 

      this.seats$.subscribe((state : SeatState) =>{
        this.seatsReservedInFlight = state.reservedSeatsInFlight;
      })  

      for(let i in this.passengersOptedSpecialmeals){
        if(this.passengersOptedSpecialmeals[i].seatNumber.length>0)
        {
          this.seatsWithSpecialMeals.push(this.passengersOptedSpecialmeals[i].seatNumber[0]);
        }
      }
  }


  getStylesClass(seat : string){

    for( let i in this.seatsWithSpecialMeals){
      if(this.seatsWithSpecialMeals[i] === seat)
      {
        return 'specialmeals'
      } 
    }
       
  }

    getSeatsAlreadyReserved(seat : string){

      for( let i in this.seatsReservedInFlight.reservedSeats){
        if(this.seatsReservedInFlight.reservedSeats[i] === seat)
        {
          return 'true'
        } 
      }
      
    }

    

}

