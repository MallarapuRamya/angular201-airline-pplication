import { Component, OnInit } from '@angular/core';
import { SocialAuthService } from 'angularx-social-login';
import { Router } from '@angular/router';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  constructor(private authService: SocialAuthService, private router : Router) { }

  ngOnInit(): void {
  }

  onLogout(){

    this.authService.signOut();
    localStorage.removeItem("token");
    this.router.navigate(['']);
    
  } 
}