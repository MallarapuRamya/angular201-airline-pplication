import { TestBed } from '@angular/core/testing';

import { FlightService } from './flight.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Observable, of } from 'rxjs';
import { Flights } from '../../models/flights.model';

let flights = [
    {
      "id": "AN001",
      "flightCompany": "SpiceJet",
      "flightFrom": "Hyderabad",
      "flightTo": "Banglore",
      "flightRoute": "HYD-BGLR",
      "flightTime": "10:00",
      "ancillaryServices": [],
      "specialMeals" :[],
      "inFlightShop" : []
    }
]

describe('FlightService', () => {
  let service: FlightService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports : [HttpClientTestingModule],
      providers : [ {provide : FlightService, useClass : FlightServiceStub }]
    });
    service = TestBed.inject(FlightService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get Flights', () => {
    expect(service.getFlights())
  });
    
}); 

export class FlightServiceStub{
    getFlights() : Observable<Flights[]> {
       return of(flights);
    }
}