import { TestBed } from '@angular/core/testing';

import { LoginService } from './login.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('LoginService', () => {
  let service: LoginService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports : [HttpClientTestingModule],
      providers : [{provide : LoginService, useClass : LoginServiceStub }]
    });
    service = TestBed.inject(LoginService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('get Token should return true', ()=>{
    expect(service.getToken).toBeTrue;
  });

  it('get AuthToken should return true', ()=>{
    expect(service.getAuthToken).toBeTrue;
  })

});

export class LoginServiceStub{
   getToken() : boolean {
     return true;
   }
   getAuthToken() : boolean {
     return true;
   }
}