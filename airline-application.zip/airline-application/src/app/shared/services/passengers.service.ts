import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from "rxjs/operators";
import { Passengers } from "../../models/passengers.model";


@Injectable({
  providedIn: 'root'
})
export class PassengersService {
  private url : string = "http://localhost:3000/passengers/";
  constructor(private http : HttpClient) {

   }

  getPassengers() : Observable<Passengers[]> {
     return this.http.get<Passengers[]>(this.url).pipe(
       tap((passengers) => {
         return  passengers;
       })
     );
  }

  reserveBooking(passenger : Passengers) : Observable<Passengers> {
    return  this.http.put<Passengers>(this.url+passenger.id,passenger).pipe(
      tap( passenger =>
       {
         return passenger;
       }
      )
    );
  }
  
  addPassenger(passenger : Passengers) : Observable<Passengers>{
    return this.http.post<Passengers>(this.url, passenger).pipe(
      tap(passenger =>
        {
          return passenger;
        })
    )
  }

  upadatePassenger(passenger : Passengers) : Observable<Passengers>{
    return this.http.patch<Passengers>(this.url+passenger.id, passenger).pipe(
      tap(passenger =>{
          return passenger;
      })
    )
  } 

}