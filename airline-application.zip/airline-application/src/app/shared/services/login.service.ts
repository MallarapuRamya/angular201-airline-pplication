import { Injectable } from '@angular/core';
import { SocialUser } from 'angularx-social-login';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  loggedIn : boolean =false;
  user : SocialUser;

  constructor() { }

  getToken()
  {
    return !!localStorage.getItem("session");
  }
  getAuthToken()
  {
    return !!localStorage.getItem("token");
  }
}