import { TestBed } from '@angular/core/testing';

import { PassengersService } from './passengers.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Observable, of } from 'rxjs';
import { Passengers } from 'src/app/models/passengers.model';

let passengers = [{
  "id": 10014,
  "flightId": "AN001",
  "name": "Surekha",
  "passport": "PAS91640",
  "gender": "female",
  "age": 20,
  "dateOfBirth": "18-05-2000",
  "address": "Chirala",
  "specialMeals": [],
  "infants": false,
  "wheelchair": false,
  "ancillaryServices": [],
  "shopInFlight": [],
  "seatNumber": [],
  "isCheckedIn": false
}]

describe('PassengersService', () => {
  let service: PassengersService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports : [HttpClientTestingModule],
      providers : [{provide : PassengersService, useClass : PassengersServiceStub }]
    });
    service = TestBed.inject(PassengersService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return empty from get passengers', () =>{
    expect(service.getPassengers);
  })

});

export class PassengersServiceStub{
  getPassengers() : Observable<Passengers[]> {
    return of(passengers);
  }
}
