import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Seats } from "../../models/seats.model";
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';



@Injectable({
  providedIn: 'root'
})
export class SeatsService {
  private baseUrl : string = "http://localhost:3000/seats/";

  constructor( private http : HttpClient) { 
  }

  getReservedSeatsBySelectedFlightId(selectedFlight : string) : Observable<Seats>{
    return this.http.get<Seats>(this.baseUrl+selectedFlight).pipe(
      tap(seats =>
        {
           return seats; 
        }
      ));
    }

  reserveSeats(seats : Seats) : Observable<Seats> {
    return  this.http.put<Seats>(this.baseUrl+seats.id, seats).pipe(
      tap( seats =>
       {
         return seats;
       }
      ));
   }
}
