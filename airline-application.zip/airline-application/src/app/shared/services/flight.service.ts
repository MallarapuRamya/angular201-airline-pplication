import { Injectable } from '@angular/core';
import { Observable  } from 'rxjs';
import { tap } from "rxjs/operators";
import { HttpClient } from "@angular/common/http";
import { Flights } from '../../models/flights.model';

@Injectable({
  providedIn: 'root'
})
export class FlightService {

  private url : string = "http://localhost:3000/flights/";

  constructor(private http : HttpClient) {
   }
 
  getFlights() : Observable<Flights[]> {
     return this.http.get<Flights[]>(this.url).pipe(
       tap((flights) =>
      {
         return flights;
      }));
  }
  changeAncillary(flight : Flights) : Observable<Flights> {
    return this.http.patch<Flights>(this.url+flight.id , flight).pipe(
       tap(flight =>{
         
             return flight;
       }) 
    )
  }
 
}
