import { TestBed } from '@angular/core/testing';

import { SeatsService } from './seats.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';

describe('SeatsService', () => {
  let service: SeatsService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports : [HttpClientTestingModule, RouterTestingModule],
      providers : [{provide : SeatsService, useClass : SeatsServiceStub }]
    });
    service = TestBed.inject(SeatsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

});

export class SeatsServiceStub{

}
