import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SocialLoginComponent } from './social-login.component';
import { SocialAuthService, SocialUser } from 'angularx-social-login';
import { RouterTestingModule } from '@angular/router/testing';
import { of, Observable } from 'rxjs';
import { Component } from '@angular/core';

describe('SocialLoginComponent', () => {
  let component: SocialLoginComponent;
  let fixture: ComponentFixture<SocialLoginComponent>;
  let user : SocialUser

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SocialLoginComponent ],
      imports : [RouterTestingModule.withRoutes([
        {path : 'staff', component : DummyComponent}
      ])], 
      providers : [ {provide : SocialAuthService, useClass : authServiceStub }]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SocialLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

   it('should signInWithGoogle', () =>{
     expect(component.signInWithGoogle()).toBeUndefined();
   });
   it('should signInWithFacebook', () =>{
      expect(component.signInWithFB()).toBeUndefined();
   })
   it('should signout',() =>{
     expect(component.signOut()).toBeUndefined();
   })
});

class authServiceStub {

      signIn():Promise<SocialUser>{
           return new Promise((value)=>{
             value({email : 'ramya.mallarapu@gmail.com'} as any);
             const location = TestBed.get(Location);
             expect(location.path()).toBe('staff');
           });
      }
      get authState(): Observable<SocialUser>{
        return of({photoUrl : '', name : '', email : ''} as any);
      }

      signOut():Promise<boolean>{
        return new Promise((value) => {
           value(false);
           const location = TestBed.get(Location);
            expect(location.path()).toBe('staff');
        })
      }
}

@Component({ template : ''})
class DummyComponent{

}