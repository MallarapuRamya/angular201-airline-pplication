import { Component, OnInit } from '@angular/core';
import { SocialAuthService } from 'angularx-social-login';
import { GoogleLoginProvider , FacebookLoginProvider} from 'angularx-social-login';
import { SocialUser } from 'angularx-social-login';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-social-login',
  templateUrl: './social-login.component.html',
  styleUrls: ['./social-login.component.css']
})
export class SocialLoginComponent implements OnInit {
  hide =true;
  isAuthenticated : boolean=true;
  user: SocialUser;
  loggedIn: boolean = false;

  constructor(private authService: SocialAuthService, private route : Router, 
    private router: ActivatedRoute, private loginService : LoginService) { }

  ngOnInit(): void {
    
    this.authService.authState.subscribe((user) => {
      this.user = user;
      this.loggedIn = (user != null);
      if(user != null)
      {
        this.loginService.user=user;
        this.loginService.loggedIn=this.loggedIn;
        this.route.navigate(['staff']);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
      }
    });

  }
  
  signInWithGoogle(): void {

    this.authService.signIn(GoogleLoginProvider.PROVIDER_ID).then(token => {
      localStorage.setItem("token", token.authToken);

    })
  
  }
  signInWithFB(): void {

    this.authService.signIn(FacebookLoginProvider.PROVIDER_ID).then(token =>
      {
        localStorage.setItem("token", token.authToken);
      });
  }
  onSignIn(username : string, password : string)
  {
    if(username === 'admin' && password === 'admin'){
      localStorage.setItem("session", "admin");
       this.route.navigate(['admin']);
    }
    else{
      this.isAuthenticated=false;
    }
  }

  signOut(): void {

    this.authService.signOut();
    localStorage.removeItem("token");

  }
}
