export class FlightMeals{
    
    mealId : number;
    mealName : string;
    mealCost : number;
    mealDesc : string;
}