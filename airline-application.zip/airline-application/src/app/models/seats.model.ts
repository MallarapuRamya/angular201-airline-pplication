export class Seats{

          id : string;
reservedSeats: string[];
  infants    :string[];
  wheelchairs :string[];
  
}