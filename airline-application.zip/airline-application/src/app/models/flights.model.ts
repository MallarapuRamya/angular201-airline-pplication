import { FlightAncillaryServices } from '../models/flightAncillaryServices.model';
import { FlightMeals } from "../models/flightMeals.model";
import { FlightPurchases } from "../models/flightpurchases.model";

export class Flights{

     id : string;
     flightCompany : string;
     flightFrom :string;
     flightTo : string;
     flightRoute : string;
     flightTime : string;
     ancillaryServices : FlightAncillaryServices[];
     specialMeals : FlightMeals[];
     inFlightShop : FlightPurchases[];
}