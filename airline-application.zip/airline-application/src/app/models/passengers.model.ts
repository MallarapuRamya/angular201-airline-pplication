
export class Passengers {
      
      id : number
      flightId : string
      name : string
      passport : string
      gender : string
      age : number
      address : string
      dateOfBirth : string
      seatNumber : string[]
      ancillaryServices : string[]
      specialMeals : string[]
      infants : boolean
      wheelchair : boolean
      shopInFlight : string[]
      isCheckedIn : boolean
}