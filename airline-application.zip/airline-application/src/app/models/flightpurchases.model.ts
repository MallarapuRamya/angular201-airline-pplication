export class FlightPurchases{
    
    purchaseId : number;
    purchaseItem : string;
    purchaseCost : number;
    purchaseDesc : string;
}