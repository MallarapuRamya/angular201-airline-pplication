export class FlightAncillaryServices{
    
    serviceId : number;
    serviceName : string;
    serviceCost : number;
    serviceDesc : string;
}