import { Injectable } from "@angular/core";
import { Actions, Effect, ofType } from "@ngrx/effects";
import { PassengersService } from "../../shared/services/passengers.service";
import { Observable } from "rxjs";
import { Action } from "@ngrx/store";
import { mergeMap, map } from "rxjs/operators";
import * as PassengerActions from '../actions/passenger.actions';

@Injectable()
export class PassengerEffects {
    constructor(private action$ : Actions, private passengerService : PassengersService){}

    @Effect()
    loadPassengers$ : Observable<Action> = this.action$.pipe(
        ofType<PassengerActions.LoadPassengers>(PassengerActions.LOAD_PASSENGERS),
        mergeMap(action => this.passengerService.getPassengers().pipe(
            map(passengers => new PassengerActions.LoadPassengersSuccess(passengers))
        ))
    );

    @Effect()
    editPassengers$ : Observable<Action> = this.action$.pipe(
        ofType<PassengerActions.EditPassengerSeatsAndAncillary>(PassengerActions.EDIT_PASSENGER_SEATS_AND_ANCILLARY),
        mergeMap(action => this.passengerService.reserveBooking(action.payload).pipe(
            map(passengers => new PassengerActions.EditPassengerSeatsAndAncillarySuccess(passengers))
        ))
    );

    @Effect()
    addPassenger$ : Observable<Action> = this.action$.pipe(
        ofType<PassengerActions.AddPassenger>(PassengerActions.ADD_PASSENGER),
        mergeMap(action => this.passengerService.addPassenger(action.payload).pipe(
            map(passenger => new PassengerActions.AddPassengerSuccess(passenger))
        ))
    );

    @Effect()
    editPassenger$ : Observable<Action> = this.action$.pipe(
        ofType<PassengerActions.EditPassenger>(PassengerActions.EDIT_PASSENGER),
        mergeMap(action => this.passengerService.upadatePassenger(action.payload).pipe(
            map(passenger => new PassengerActions.EditPassengerSuccess(passenger))
        ))
    );
}