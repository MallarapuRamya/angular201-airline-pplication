import { Injectable } from "@angular/core";
import { Actions ,Effect ,ofType } from "@ngrx/effects";
import { Store , Action } from "@ngrx/store";
import { Observable } from "rxjs";
import { mergeMap, map } from "rxjs/operators";
import {SeatsService} from '../../shared/services/seats.service'
import * as SeatActions from "../actions/seat.actions";
import * as fromApp from '../reducers/app.reducer'


 


 @Injectable()
 export class SeatEffects{
 
     constructor(private action$ : Actions,
         private store : Store<fromApp.AppState>,
          private seatService : SeatsService){}
 
     @Effect()
     loadSeatsByFlightId$ : Observable<Action> = this.action$.pipe(
         ofType<SeatActions.LoadSeatsByFlightId>(SeatActions.LOAD_SEATS_BY_FLIGHT_ID),
         mergeMap(data => this.seatService.getReservedSeatsBySelectedFlightId(data.payload).pipe(
             map(seats => new SeatActions.LoadSeatsByFlightIdSuccess(seats))
         ))
     );

     @Effect()
     reserveSeats$ : Observable<Action> = this.action$.pipe(
         ofType<SeatActions.ReserveSeats>(SeatActions.RESERVE_SEATS),
         mergeMap(data => this.seatService.reserveSeats(data.payload).pipe(
             map(seats => new SeatActions.ReserveSeatsSuccess(seats))
         ))
     );
 }