import { Injectable } from "@angular/core";
import { Actions ,Effect ,ofType } from "@ngrx/effects";
import { Store , Action } from "@ngrx/store";
import { Observable } from "rxjs";
import { FlightService } from "../../shared/services/flight.service";
import { mergeMap, map } from "rxjs/operators";
import * as fromApp from '../reducers/app.reducer';
import * as FlightActions from '../actions/flight.actions';



@Injectable()
export class FlightEffects{

    constructor(private action$ : Actions,
        private store : Store<fromApp.AppState>,
         private flightService : FlightService){}

    @Effect()
    loadFlights$ : Observable<Action> = this.action$.pipe(
        ofType<FlightActions.FlightsActionsUnion>(FlightActions.LOAD_FLIGHTS), 
        mergeMap(action =>this.flightService.getFlights().pipe(
            map(flights => new FlightActions.LoadFlightsSuccess(flights))
        ))
    );

    @Effect()
    updateAncillaryInFlight$ : Observable<Action> = this.action$.pipe(
        ofType<FlightActions.UpdateAncillaryInFlight>(FlightActions.UPDATE_ANCILLARY_IN_FLIGHT),
        mergeMap(action =>this.flightService.changeAncillary(action.payload).pipe(
            map(flight => new FlightActions.UpdateAncillaryInFlightSuccess(flight))
        ))
    );
}