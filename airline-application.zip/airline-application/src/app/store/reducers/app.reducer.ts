import { ActionReducerMap } from "@ngrx/store";
import * as fromFlight from '../reducers/flight.reducer'
import * as fromPassenger from '../reducers/passenger.reducer'
import * as fromSeat from '../reducers/seat.reducer'

export interface AppState{
  flightState : fromFlight.State;
  passengerState : fromPassenger.PassengerState;
  seatState : fromSeat.SeatState;
}

export const appReducer : ActionReducerMap<AppState> = {
    flightState : fromFlight.FlightReducer,
    passengerState : fromPassenger.PassengerReducer,
    seatState    : fromSeat.SeatReducer
}