import { Passengers } from "../../models/passengers.model";
import * as PassengerActions from '../actions/passenger.actions'



export interface PassengerState{
    passengers : Passengers[];
    loading : boolean;
    loaded : boolean;
    currentPassengerIdSelected : number ;
}
const initialState : PassengerState = {
    passengers:[],
    loading :false,
    loaded : false,
    currentPassengerIdSelected : null
}

export function PassengerReducer (state = initialState , action : PassengerActions.PassengerActionsUnion){
    switch(action.type)
    {
        case PassengerActions.LOAD_PASSENGERS :
            return {...state, loading : true, loaded : false};
        case PassengerActions.LOAD_PASSENGERS_SUCCESS :
            return {...state, passengers : action.payload, loading : false, loaded : true};
        case PassengerActions.CURRENT_PASSENGER_ID_SELECTED :
            return {...state, currentPassengerIdSelected : action.payload };
        case PassengerActions.EDIT_PASSENGER_SEATS_AND_ANCILLARY :
            return {...state, loading : true, loaded : false};
        case PassengerActions.EDIT_PASSENGER_SEATS_AND_ANCILLARY_SUCCESS:
                return {...state, passengers : state.passengers.map(passenger =>
                    {
                        if(passenger.id === action.payload.id){

                            return action.payload;
                        }
                        else{
                            return passenger;
                        }
                    })   ,loading : false, loaded : true};
        case PassengerActions.ADD_PASSENGER :
                return {...state, loading : true, loaded : false};
        case PassengerActions.ADD_PASSENGER_SUCCESS :
                    return {...state, passengers : [...state.passengers, action.payload],loading : false, loaded : true};
        case PassengerActions.EDIT_PASSENGER :
            return {...state, loading : true, loaded : false};
        case PassengerActions.EDIT_PASSENGER_SUCCESS :
            return {...state, passengers : state.passengers.map(passenger =>
                {
                    if(passenger.id === action.payload.id)
                    {
                        return action.payload;
                    }
                    else{
                        return passenger;
                    }
                }
            )};
        default :
            return state;
    }
}
