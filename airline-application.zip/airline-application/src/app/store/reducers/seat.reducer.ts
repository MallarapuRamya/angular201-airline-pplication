import { Seats } from "../../models/seats.model";
import * as SeatActions from "../actions/seat.actions";

export interface SeatState{
    
    reservedSeatsInFlight : Seats;
    loading : boolean;
    loaded : boolean;
   }

const initialState : SeatState = {
    reservedSeatsInFlight : new Seats(),
    loading :false,
    loaded : false,
}

export function SeatReducer(state = initialState, action : SeatActions.SeatsActionsUnion){
    switch(action.type)
    {
        case SeatActions.LOAD_SEATS_BY_FLIGHT_ID :
            return {...state, loaded : false, loading : true};
        case SeatActions.LOAD_SEATS_BY_FLIGHT_ID_SUCCESS :
            return {...state, reservedSeatsInFlight : action.payload, loaded : true, loading : false };
        case SeatActions.RESERVE_SEATS :
            return {...state, loaded : false, loading : true};
        case SeatActions.RESERVE_SEATS_SUCCESS :
            return {...state, reservedSeatsInFlight : action.payload, loaded : true, loading : false};
        default :
           return state;
    }
}