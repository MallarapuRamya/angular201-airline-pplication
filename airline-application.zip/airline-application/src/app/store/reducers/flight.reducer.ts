 import { Flights } from '../../models/flights.model';
 import * as FlightActions from '../actions/flight.actions'


export interface State{
 flights : Flights[];
 loading : boolean;
 loaded : boolean;
 currentFlightIdSelected : string ;
 currentAncillaryIdSelected : number;
 currentMealIdSelected : number ;
 currentPurchaseIdSelected : number;
}

const initialState : State = {
    flights:[],
    loading :false,
    loaded : false,
    currentFlightIdSelected : null,
    currentAncillaryIdSelected : null,
    currentMealIdSelected : null,
    currentPurchaseIdSelected : null
}

export function FlightReducer(state = initialState, action : FlightActions.FlightsActionsUnion){
    switch(action.type)
    {
        case FlightActions.LOAD_FLIGHTS :
            return {...state, loaded : false, loading : true};
        case FlightActions.LOAD_FLIGHTS_SUCCESS :
            return {...state, flights : action.payload, loaded : true, loading : false };
        case FlightActions.CURRENT_FLIGHT_ID_SELECTED :
            return {...state, currentFlightIdSelected : action.payload };
        case FlightActions.CURRENT_ANCILLARY_ID_SELECTED :
                return {...state, currentAncillaryIdSelected : action.payload };
        case FlightActions.CURRENT_MEAL_ID_SELECTED : 
                return {...state, currentMealIdSelected : action.payload };
        case FlightActions.CURRENT_PURCHASE_ID_SELECTED :
                return {...state, currentPurchaseIdSelected : action.payload };
        case FlightActions.UPDATE_ANCILLARY_IN_FLIGHT :
                return {...state, loading : true, loaded : false };
        case FlightActions.UPDATE_ANCILLARY_IN_FLIGHT_SUCCESS:
                return {...state, flights : state.flights.map(flight =>{

                         if(flight.id === action.payload.id){

                            return action.payload;
                         }
                         else{
                             return flight;
                         }
                }),
                    loading : false, loaded : true };
        default :
                return state;
    }
}