import { Action } from "@ngrx/store";
import { Seats } from "../../models/seats.model";

export const LOAD_SEATS_BY_FLIGHT_ID = '[Seats] Load seats by flight id';
export const LOAD_SEATS_BY_FLIGHT_ID_SUCCESS = '[Seats] Load seats by flight id success';
export const RESERVE_SEATS ='[Seats] Reserve seats';
export const RESERVE_SEATS_SUCCESS = '[seats] Reserve seats success';

export class LoadSeatsByFlightId implements Action{
    readonly type = LOAD_SEATS_BY_FLIGHT_ID;
    constructor(public payload : string){}
}

export class LoadSeatsByFlightIdSuccess implements Action{
    readonly type = LOAD_SEATS_BY_FLIGHT_ID_SUCCESS;
    constructor(public payload : Seats){}
}

export class ReserveSeats implements Action{
    readonly type = RESERVE_SEATS;
    constructor(public payload : Seats){}
}

export class ReserveSeatsSuccess implements Action{
    readonly type = RESERVE_SEATS_SUCCESS;
    constructor(public payload : Seats){}
}

export type SeatsActionsUnion = LoadSeatsByFlightId | LoadSeatsByFlightIdSuccess 
                                | ReserveSeats | ReserveSeatsSuccess;
