import { Action } from "@ngrx/store";
import { Flights } from "../../models/flights.model";


export const LOAD_FLIGHTS = '[Flights] Load flights';
export const LOAD_FLIGHTS_SUCCESS = '[Flights] Load flights success';
export const CURRENT_FLIGHT_ID_SELECTED = '[Flights] Current flight id selected';
export const CURRENT_ANCILLARY_ID_SELECTED = '[Flights] Current ancillary id selected';
export const CURRENT_MEAL_ID_SELECTED = '[Flights] Current meal id selected';
export const CURRENT_PURCHASE_ID_SELECTED ='[Flights] Current purchase id selected';
export const UPDATE_ANCILLARY_IN_FLIGHT = '[Flights] Update ancillary in flight';
export const UPDATE_ANCILLARY_IN_FLIGHT_SUCCESS = '[Flights] Update ancillary in flight success';

export class LoadFlights implements Action{
    readonly type = LOAD_FLIGHTS;
}
export class LoadFlightsSuccess implements Action
{
   readonly type = LOAD_FLIGHTS_SUCCESS;
   constructor(public payload : Flights[]){}
}
export class CurrentFlightIdSelected implements Action{
    readonly type = CURRENT_FLIGHT_ID_SELECTED; 
    constructor(public payload : string){}
}
export class CurrentAncillaryIdSelected implements Action {
    readonly type = CURRENT_ANCILLARY_ID_SELECTED;
    constructor(public payload : number ){}
}
export class CurrentMealIdSelected implements Action {
    readonly type = CURRENT_MEAL_ID_SELECTED;
    constructor(public payload : number ){}
}

export class CurrentPurchaseIdSelected implements Action {
    readonly type = CURRENT_PURCHASE_ID_SELECTED;
    constructor(public payload : number ){}
}

export class UpdateAncillaryInFlight implements Action{
    readonly type= UPDATE_ANCILLARY_IN_FLIGHT;
    constructor(public payload : Flights){}
}

export class UpdateAncillaryInFlightSuccess implements Action{
    readonly type= UPDATE_ANCILLARY_IN_FLIGHT_SUCCESS;
    constructor(public payload : Flights){}
}

export type FlightsActionsUnion = LoadFlights | LoadFlightsSuccess | CurrentFlightIdSelected 
| CurrentAncillaryIdSelected | UpdateAncillaryInFlight | UpdateAncillaryInFlightSuccess
 | CurrentMealIdSelected | CurrentPurchaseIdSelected;