import { Action } from "@ngrx/store";
import { Passengers } from "../../models/passengers.model";

export const LOAD_PASSENGERS = '[Passengers] Load passengers';
export const LOAD_PASSENGERS_SUCCESS = '[Passengers] Load passengers success';
export const CURRENT_PASSENGER_ID_SELECTED = '[Passengers] Current passenger id selected'
export const EDIT_PASSENGER_SEATS_AND_ANCILLARY= '[Passengers] Edit passenger seats and ancillary';
export const EDIT_PASSENGER_SEATS_AND_ANCILLARY_SUCCESS = '[Passengers] Edit passenger seats and ancillary success';
export const ADD_PASSENGER = '[Passengers] Add passenger';
export const ADD_PASSENGER_SUCCESS = '[Passengers] Add passenger success';
export const EDIT_PASSENGER ='[Passengers] Edit passenger';
export const EDIT_PASSENGER_SUCCESS ='[Passengers] Edit passenger success';

export class LoadPassengers implements Action{
   readonly type = LOAD_PASSENGERS;
}
export class LoadPassengersSuccess implements Action{
    readonly type = LOAD_PASSENGERS_SUCCESS;
    constructor(public payload : Passengers[]){}
 }
 export class CurrentPassengerIdSelected implements Action{
   readonly type = CURRENT_PASSENGER_ID_SELECTED;
   constructor(public payload : number){}
}
export class EditPassengerSeatsAndAncillary implements Action {
  readonly type = EDIT_PASSENGER_SEATS_AND_ANCILLARY;
  constructor(public payload : Passengers){}
   
}
export class EditPassengerSeatsAndAncillarySuccess implements Action {
   readonly type = EDIT_PASSENGER_SEATS_AND_ANCILLARY_SUCCESS;
   constructor(public payload : Passengers){}
    
 }

 export class AddPassenger implements Action {
   readonly type = ADD_PASSENGER;
   constructor(public payload : Passengers){}
    
 }

 export class AddPassengerSuccess implements Action {
   readonly type = ADD_PASSENGER_SUCCESS;
   constructor(public payload : Passengers){}
    
 }

 export class EditPassenger implements Action {
   readonly type = EDIT_PASSENGER;
   constructor(public payload : Passengers){}
    
 }

 export class EditPassengerSuccess implements Action {
   readonly type = EDIT_PASSENGER_SUCCESS;
   constructor(public payload : Passengers){}
    
 }

 export type PassengerActionsUnion = LoadPassengers | LoadPassengersSuccess 
 | CurrentPassengerIdSelected | EditPassengerSeatsAndAncillary | EditPassengerSeatsAndAncillarySuccess 
 | AddPassenger | AddPassengerSuccess | EditPassenger | EditPassengerSuccess;