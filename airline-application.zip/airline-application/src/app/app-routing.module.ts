import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { AdminComponent } from './admin/admin.component';
import { StaffComponent } from './staff/staff.component';
import { SocialLoginComponent } from './shared/social-login/social-login.component';
import { StaffLandingComponent } from './staff/staff-landing/staff-landing.component';
import { SeatMapComponent } from './staff/seat-map/seat-map.component';
import { PassengerDetailsComponent } from "./staff/passenger-details/passenger-details.component";
import { BookingDetailsComponent } from "./staff/booking-details/booking-details.component";
import { EditAncillaryServicesComponent } from './staff/edit-ancillary-services/edit-ancillary-services.component';
import { ChekedInPassengersComponent } from './staff/cheked-in-passengers/cheked-in-passengers.component';
import { AdminLandingComponent } from './admin/admin-landing/admin-landing.component';
import { ManageFlightsComponent } from './admin/manage-flights/manage-flights.component';
import { ManagePassengersComponent } from './admin/manage-passengers/manage-passengers.component';
import { AddPassengerComponent } from './admin/manage-passengers/add-passenger/add-passenger.component';
import { UpdatePassengerComponent } from './admin/manage-passengers/update-passenger/update-passenger.component';
import { ManageAncillaryComponent } from './admin/manage-flights/manage-ancillary/manage-ancillary.component';
import { AddAncillaryComponent } from "./admin/manage-flights/manage-ancillary/add-ancillary/add-ancillary.component";
import { UpdateAncillaryComponent } from "./admin/manage-flights/manage-ancillary/update-ancillary/update-ancillary.component";
import { DeleteAncillaryComponent } from "./admin/manage-flights/manage-ancillary/delete-ancillary/delete-ancillary.component";
import { ManageMealsComponent } from './admin/manage-flights/manage-meals/manage-meals.component';
import { AddMealsComponent } from './admin/manage-flights/manage-meals/add-meals/add-meals.component';
import { UpdateMealsComponent } from './admin/manage-flights/manage-meals/update-meals/update-meals.component';
import { ManageInflightshopComponent } from './admin/manage-flights/manage-inflightshop/manage-inflightshop.component';
import { AddPurchaseItemComponent } from './admin/manage-flights/manage-inflightshop/add-purchase-item/add-purchase-item.component';
import { UpdatePurchaseItemComponent } from "./admin/manage-flights/manage-inflightshop/update-purchase-item/update-purchase-item.component";
import { PageNotFoundComponent } from './shared/page-not-found/page-not-found.component';
import { AuthGuard } from "./authentication/auth-guard.guard";
import { StaffAuthGuard } from './authentication/staff-auth.guard';
import { FlightDetailsComponent } from './staff/flight-details/flight-details.component';
import { CheckInComponent } from './staff/check-in/check-in.component';
import { InFlightComponent } from './staff/in-flight/in-flight.component';
import { ChangeSeatComponent } from './staff/change-seat/change-seat.component';

const routes: Routes = [
  {path : '', component : HeaderComponent},

  {path : 'admin', component : AdminComponent, canActivate:[AuthGuard],children : [
    {path : '', component : AdminLandingComponent},
    {path : 'manage-flights', component : ManageFlightsComponent},
    {path : 'manage-ancillary', component : ManageAncillaryComponent},
    {path : 'add-ancillary', component : AddAncillaryComponent },
    {path : 'update-ancillary', component : UpdateAncillaryComponent },
    {path : 'delete-ancillary', component : DeleteAncillaryComponent},
    {path : 'manage-meals', component : ManageMealsComponent},
    {path : 'add-meals', component : AddMealsComponent},
    {path : 'update-meals', component : UpdateMealsComponent},
    {path : 'manage-inflightshop', component : ManageInflightshopComponent},
    {path : 'add-purchase', component : AddPurchaseItemComponent},
    {path : 'update-purchase', component : UpdatePurchaseItemComponent },
    {path : 'manage-passengers', component : ManagePassengersComponent},
    {path : 'add', component : AddPassengerComponent},
    {path : 'update', component : UpdatePassengerComponent},
   ]},

  {path : 'staff', component : StaffComponent, canActivate:[StaffAuthGuard], children :[
  {path : '', component : StaffLandingComponent},
  {path : 'check-in', component : CheckInComponent},
  {path : 'in-flight', component : InFlightComponent},
  {path : 'passengers', component : PassengerDetailsComponent},
  {path : 'flight', component : FlightDetailsComponent},
  {path : 'change-seat', component : ChangeSeatComponent},
  {path : 'seat-map', component : SeatMapComponent},
  {path : 'booking-details', component : BookingDetailsComponent},
  {path : 'checked-in-passengers', component : ChekedInPassengersComponent},
  {path : 'edit-ancillary' , component : EditAncillaryServicesComponent},
  ]},
  
   {path : 'login', component : SocialLoginComponent},
   {path : 'not-found', component : PageNotFoundComponent},
   {path : '**' , redirectTo : '/not-found'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
